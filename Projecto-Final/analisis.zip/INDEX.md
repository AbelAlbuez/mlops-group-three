# 📚 Índice de Documentación - Scripts de Análisis de Carga

Guía de navegación rápida para todos los archivos incluidos en este paquete.

---

## 🎯 Por Dónde Empezar

### Si es tu primera vez...
**Lee:** [START_HERE.md](./START_HERE.md)  
Resumen ejecutivo con todo lo esencial.

### Si quieres instalar las herramientas...
**Lee:** [INSTALLATION.md](./INSTALLATION.md)  
Guía de instalación paso a paso.

### Si quieres ejecutar el análisis...
**Ejecuta:** `./quick_start.sh`  
Menú interactivo con todas las opciones.

---

## 📖 Documentación

### [START_HERE.md](./START_HERE.md)
**¿Qué es?** Resumen ejecutivo del paquete  
**¿Cuándo leerlo?** Primer contacto con los scripts  
**Contenido clave:**
- Descripción de cada archivo
- Guía de inicio rápido
- ¿Qué script usar?
- Métricas clave
- Credenciales

### [INSTALLATION.md](./INSTALLATION.md)
**¿Qué es?** Guía de instalación y preparación  
**¿Cuándo leerlo?** Antes de ejecutar cualquier script  
**Contenido clave:**
- Instalación en macOS/Linux
- Verificación de prerequisitos
- Configuración de SSH
- Troubleshooting de instalación
- Checklist de preparación

### [LOAD_TEST_README.md](./LOAD_TEST_README.md)
**¿Qué es?** Documentación técnica completa  
**¿Cuándo leerlo?** Para entender los detalles  
**Contenido clave:**
- Guía detallada de cada script
- Configuración avanzada
- Interpretación de resultados
- Análisis de métricas
- Troubleshooting completo
- Best practices

### [EXAMPLES.md](./EXAMPLES.md)
**¿Qué es?** Ejemplos prácticos de uso  
**¿Cuándo leerlo?** Para casos de uso específicos  
**Contenido clave:**
- 7 escenarios prácticos
- Código y comandos reales
- Tips para cada situación
- Guía para presentación
- Checklist de uso

---

## 🚀 Scripts Ejecutables

### [quick_start.sh](./quick_start.sh) ⭐ RECOMENDADO
**¿Qué hace?** Menú interactivo principal  
**¿Cuándo usarlo?** Primera vez y uso general  
**Características:**
- Verificación de prerequisitos
- Acceso a todos los scripts
- Verificación de servicios
- Vista de URLs
- Documentación integrada

**Uso:**
```bash
chmod +x quick_start.sh
./quick_start.sh
```

---

### [load_test_analysis.sh](./load_test_analysis.sh) ⭐ ANÁLISIS COMPLETO
**¿Qué hace?** Análisis completo automatizado  
**¿Cuándo usarlo?** Para el análisis del proyecto  
**Características:**
- 5 pruebas progresivas (10-200 usuarios)
- Captura de métricas K8s
- Captura de métricas Prometheus
- Escalado a 2 réplicas
- Comparación 1 vs 2 réplicas
- Generación de reporte Markdown
- Restauración automática

**Uso:**
```bash
./load_test_analysis.sh
```

**Duración:** ~20-30 minutos  
**Resultado:** Carpeta `load_test_results_YYYYMMDD_HHMMSS/`

---

### [run_single_test.sh](./run_single_test.sh) ⭐ PRUEBAS RÁPIDAS
**¿Qué hace?** Ejecuta una prueba individual  
**¿Cuándo usarlo?** Testing rápido o debug  
**Características:**
- Configuración personalizable
- Verificación de servicios
- Barra de progreso
- Resultados inmediatos
- Indicador de éxito/fallo

**Uso:**
```bash
./run_single_test.sh <usuarios> [segundos]

# Ejemplos:
./run_single_test.sh 10      # 10 usuarios, 60s
./run_single_test.sh 50 120  # 50 usuarios, 120s
```

**Duración:** 1-5 minutos

---

### [capture_grafana.sh](./capture_grafana.sh)
**¿Qué hace?** Captura info de dashboards  
**¿Cuándo usarlo?** Para documentación/presentación  
**Características:**
- Lista de dashboards
- Metadata en JSON
- Instrucciones para screenshots

**Uso:**
```bash
./capture_grafana.sh
```

**Resultado:** Carpeta `grafana_screenshots/`

---

## 🗂️ Estructura de Archivos

```
load_test_scripts/
│
├── 📄 Documentación
│   ├── INDEX.md                  ← Este archivo
│   ├── START_HERE.md             ← Lee primero
│   ├── INSTALLATION.md           ← Instalación
│   ├── LOAD_TEST_README.md       ← Documentación completa
│   └── EXAMPLES.md               ← Ejemplos prácticos
│
└── 🔧 Scripts
    ├── quick_start.sh            ⭐ Menú interactivo
    ├── load_test_analysis.sh     ⭐ Análisis completo
    ├── run_single_test.sh        ⭐ Pruebas individuales
    └── capture_grafana.sh          Captura de Grafana
```

---

## 🎯 Flujo de Trabajo Recomendado

### Primera Vez

```
1. Lee START_HERE.md
   └─→ Entiendes qué hace cada archivo
   
2. Lee INSTALLATION.md
   └─→ Instalas herramientas necesarias
   
3. Ejecuta quick_start.sh
   └─→ Verificas que todo funciona
   
4. Ejecuta prueba pequeña (opción 2 del menú)
   └─→ 10 usuarios, 30 segundos
   
5. Si todo OK, ejecuta análisis completo (opción 1)
   └─→ Análisis de ~30 minutos
```

### Para el Proyecto

```
1. Ejecuta load_test_analysis.sh
   └─→ Análisis completo automatizado
   
2. Revisa LOAD_TEST_REPORT.md generado
   └─→ Resultados y análisis
   
3. Ejecuta capture_grafana.sh
   └─→ Info de dashboards
   
4. Captura screenshots manualmente
   └─→ Para presentación
   
5. Lee EXAMPLES.md sección 7
   └─→ Preparar materiales de presentación
```

### Para Debug

```
1. Lee EXAMPLES.md sección 6
   └─→ Debug de performance
   
2. Ejecuta run_single_test.sh
   └─→ Pruebas incrementales
   
3. Monitorea en Grafana
   └─→ http://10.43.100.87:3010
   
4. Lee LOAD_TEST_README.md
   └─→ Troubleshooting
```

---

## 📊 Salidas y Resultados

### De load_test_analysis.sh

```
load_test_results_YYYYMMDD_HHMMSS/
├── LOAD_TEST_REPORT.md        ← Reporte principal ⭐
├── test.log                   ← Log completo
├── metrics/
│   ├── test_10_users_stats.json
│   ├── test_10_users_before_k8s_metrics.txt
│   ├── test_10_users_after_k8s_metrics.txt
│   ├── test_10_users_prometheus_metrics.json
│   └── ... (archivos similares para cada prueba)
└── logs/
```

### De run_single_test.sh

**Salida en terminal:**
- Total requests
- Total failures
- Error %
- Latencias (min/avg/max/median)
- RPS
- Indicador ✓/✗

### De capture_grafana.sh

```
grafana_screenshots/
├── dashboards_info.txt        ← Lista de dashboards
└── dashboards.json            ← Metadata completa
```

---

## 🔗 Enlaces Rápidos

### Servicios en la VM

| Servicio | URL | Credenciales |
|----------|-----|--------------|
| API | http://10.43.100.87:8001 | - |
| API Docs | http://10.43.100.87:8001/docs | - |
| Locust | http://10.43.100.87:8004 | - |
| Streamlit | http://10.43.100.87:8003 | - |
| Grafana | http://10.43.100.87:3010 | admin/admin123 |
| Prometheus | http://10.43.100.87:3011 | - |

### SSH a la VM

```bash
ssh estudiante@10.43.100.87
# Password: Fl4m3nc0*15*
```

---

## 🎓 Para Aprender

### Conceptos Básicos
**Lee:** START_HERE.md + INSTALLATION.md  
**Tiempo:** 10 minutos

### Uso Completo
**Lee:** LOAD_TEST_README.md  
**Tiempo:** 30 minutos

### Dominio Total
**Lee:** Todo + prueba varios escenarios de EXAMPLES.md  
**Tiempo:** 2 horas

---

## 🆘 ¿Necesitas Ayuda?

### Problemas de Instalación
→ [INSTALLATION.md](./INSTALLATION.md) sección Troubleshooting

### Problemas de Ejecución
→ [LOAD_TEST_README.md](./LOAD_TEST_README.md) sección Troubleshooting

### Dudas sobre Cómo Usar
→ [EXAMPLES.md](./EXAMPLES.md) ejemplos prácticos

### Dudas sobre Resultados
→ [LOAD_TEST_README.md](./LOAD_TEST_README.md) sección Interpretación

---

## ✅ Checklist Rápido

Antes de empezar:
- [ ] Leí START_HERE.md
- [ ] Instalé herramientas (INSTALLATION.md)
- [ ] Di permisos: `chmod +x *.sh`
- [ ] Verifiqué servicios con quick_start.sh
- [ ] Ejecuté prueba pequeña de verificación

Para el proyecto:
- [ ] Ejecuté análisis completo
- [ ] Revisé LOAD_TEST_REPORT.md
- [ ] Capturé screenshots de Grafana
- [ ] Preparé materiales según EXAMPLES.md sección 7

---

**¿Por dónde empiezo?**

```bash
# 1. Da permisos
chmod +x *.sh

# 2. Ejecuta el menú
./quick_start.sh

# 3. Sigue las opciones del menú
```

---

*Proyecto 3 - MLOps*  
*Pontificia Universidad Javeriana*  
*Noviembre 2025*
