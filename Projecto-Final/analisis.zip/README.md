# 🚀 Scripts de Análisis de Carga - Proyecto 3 MLOps

> **Paquete completo de scripts automatizados para análisis de pruebas de carga con Locust en Kubernetes**

[![Estado](https://img.shields.io/badge/estado-listo-success)](.)
[![Plataforma](https://img.shields.io/badge/plataforma-macOS%20%7C%20Linux-blue)](.)
[![Licencia](https://img.shields.io/badge/licencia-MIT-green)](.)

---

## 📦 Contenido del Paquete

Este paquete contiene **9 archivos** organizados para facilitar el análisis de carga:

### 📖 Documentación (5 archivos)

| Archivo | Propósito | Lee Esto Si... |
|---------|-----------|----------------|
| **[INDEX.md](./INDEX.md)** | Índice navegable | Quieres ver el mapa completo |
| **[START_HERE.md](./START_HERE.md)** ⭐ | Resumen ejecutivo | Es tu primera vez |
| **[INSTALLATION.md](./INSTALLATION.md)** | Guía de instalación | Necesitas instalar herramientas |
| **[LOAD_TEST_README.md](./LOAD_TEST_README.md)** | Documentación técnica | Quieres entender los detalles |
| **[EXAMPLES.md](./EXAMPLES.md)** | Ejemplos prácticos | Quieres casos de uso reales |

### 🔧 Scripts Ejecutables (4 archivos)

| Script | Propósito | Usa Esto Para... |
|--------|-----------|------------------|
| **[quick_start.sh](./quick_start.sh)** ⭐ | Menú interactivo | Acceso fácil a todo |
| **[load_test_analysis.sh](./load_test_analysis.sh)** 🎯 | Análisis completo | Análisis del proyecto |
| **[run_single_test.sh](./run_single_test.sh)** ⚡ | Pruebas individuales | Testing rápido |
| **[capture_grafana.sh](./capture_grafana.sh)** 📊 | Captura de Grafana | Documentación visual |

---

## ⚡ Inicio en 3 Pasos

```bash
# 1. Dar permisos
chmod +x *.sh

# 2. Ejecutar menú interactivo
./quick_start.sh

# 3. ¡Listo! Sigue las opciones del menú
```

---

## 🎯 ¿Qué Script Usar?

```
┌─────────────────────────────────────────────────────────────┐
│                    ¿Qué necesitas hacer?                    │
└─────────────────────────────────────────────────────────────┘

Primera vez usando los scripts
  └→ ./quick_start.sh
     (Menú interactivo con verificaciones)

Análisis completo para el proyecto
  └→ ./load_test_analysis.sh
     (Análisis automatizado de ~30 min)

Prueba rápida o debug
  └→ ./run_single_test.sh 10
     (Prueba individual de 1-5 min)

Capturar info de Grafana
  └→ ./capture_grafana.sh
     (Extrae metadata de dashboards)
```

---

## 📊 Lo Que Obtendrás

### Del Análisis Completo

```
load_test_results_YYYYMMDD_HHMMSS/
├── LOAD_TEST_REPORT.md          ← Reporte con tablas comparativas
├── test.log                     ← Log completo de ejecución
├── metrics/
│   ├── *_stats.json            ← Estadísticas de Locust
│   ├── *_k8s_metrics.txt       ← Métricas de Kubernetes
│   └── *_prometheus_metrics.json ← Métricas de Prometheus
└── logs/                        ← Logs detallados
```

### Del Reporte Principal

- ✅ Tabla con resultados de 5 pruebas (10-200 usuarios)
- ✅ Comparación 1 vs 2 réplicas
- ✅ Métricas: requests, failures, latencias, RPS, error %
- ✅ Análisis de resultados
- ✅ Recomendaciones de configuración

---

## 🛠️ Prerequisitos

### Herramientas Requeridas

```bash
# macOS
brew install hudochenkov/sshpass/sshpass
brew install jq bc  # Opcionales pero recomendados

# Linux (Ubuntu/Debian)
sudo apt install -y sshpass jq bc

# Linux (Rocky/CentOS)
sudo dnf install -y epel-release
sudo dnf install -y sshpass jq bc
```

### Servicios Necesarios (en la VM)

- ✅ API en puerto 8001
- ✅ Locust en puerto 8004
- ✅ Grafana en puerto 3010
- ✅ Prometheus en puerto 3011
- ✅ Kubernetes con deployment de API

---

## 🔗 URLs y Credenciales

### Servicios

| Servicio | URL | Credenciales |
|----------|-----|--------------|
| API | http://10.43.100.87:8001 | - |
| Locust | http://10.43.100.87:8004 | - |
| Grafana | http://10.43.100.87:3010 | admin/admin123 |
| Prometheus | http://10.43.100.87:3011 | - |

### VM SSH

```bash
ssh estudiante@10.43.100.87
# Password: Fl4m3nc0*15*
```

---

## 📈 Características Principales

### Script de Análisis Completo

- ✅ **5 pruebas progresivas** (10, 25, 50, 100, 200 usuarios)
- ✅ **Captura automática** de métricas K8s y Prometheus
- ✅ **Escalado inteligente** a 2 réplicas
- ✅ **Comparación automática** 1 vs 2 réplicas
- ✅ **Reporte en Markdown** con tablas y análisis
- ✅ **Restauración automática** a configuración original

### Menú Interactivo

- ✅ **Verificación de prerequisitos** automática
- ✅ **Verificación de servicios** antes de ejecutar
- ✅ **Acceso a todas las funciones** desde un solo lugar
- ✅ **Documentación integrada** en el menú
- ✅ **Navegación intuitiva** con opciones numeradas

### Pruebas Individuales

- ✅ **Configuración flexible** (usuarios y duración)
- ✅ **Barra de progreso** en tiempo real
- ✅ **Resultados inmediatos** al finalizar
- ✅ **Indicador de éxito/fallo** visual
- ✅ **Verificación de servicios** previa

---

## 🎓 Documentación

### Niveles de Profundidad

**Nivel 1: Básico** (10 min)
- Lee: [START_HERE.md](./START_HERE.md)
- Lee: [INSTALLATION.md](./INSTALLATION.md)
- Ejecuta: `./quick_start.sh`

**Nivel 2: Intermedio** (30 min)
- Lee: [LOAD_TEST_README.md](./LOAD_TEST_README.md)
- Ejecuta: `./load_test_analysis.sh`
- Revisa el reporte generado

**Nivel 3: Avanzado** (2 horas)
- Lee todo + [EXAMPLES.md](./EXAMPLES.md)
- Ejecuta múltiples escenarios
- Experimenta con configuraciones

---

## 📋 Checklist de Uso

### Antes de Empezar

- [ ] Instalé sshpass y herramientas opcionales
- [ ] Di permisos: `chmod +x *.sh`
- [ ] Verifiqué conectividad SSH a la VM
- [ ] Verifiqué que servicios estén corriendo
- [ ] Leí START_HERE.md

### Para el Proyecto

- [ ] Ejecuté análisis completo
- [ ] Revisé LOAD_TEST_REPORT.md
- [ ] Capturé screenshots de Grafana
- [ ] Organicé materiales para presentación
- [ ] Preparé explicación de resultados

---

## 🐛 Troubleshooting Rápido

### Error: "sshpass: command not found"
```bash
brew install hudochenkov/sshpass/sshpass  # macOS
sudo apt install sshpass                   # Linux
```

### Error: "Cannot connect to services"
```bash
# Verificar servicios
curl http://10.43.100.87:8001/health
curl http://10.43.100.87:8004
```

### Error: "Permission denied"
```bash
chmod +x *.sh
```

### Más ayuda
- Ver [INSTALLATION.md](./INSTALLATION.md) sección Troubleshooting
- Ver [LOAD_TEST_README.md](./LOAD_TEST_README.md) sección Troubleshooting

---

## 💡 Tips

1. **Empieza con el menú interactivo** - Es la forma más fácil
2. **Haz una prueba pequeña primero** - Verifica que todo funciona
3. **Monitorea en tiempo real** - Abre Grafana durante las pruebas
4. **Lee el reporte completo** - Tiene análisis valiosos
5. **Guarda los resultados** - Son útiles para comparaciones

---

## 🎬 Para la Presentación

1. **Ejecuta el análisis completo** → Obtén datos reales
2. **Captura screenshots de Grafana** → Visualización de métricas
3. **Ejecuta una prueba en vivo** → Demostración en tiempo real
4. **Muestra el reporte** → Explica resultados y análisis
5. **Explica la configuración** → Arquitectura y decisiones

---

## 📞 Ayuda

### Documentación

| Pregunta | Archivo |
|----------|---------|
| ¿Por dónde empiezo? | [INDEX.md](./INDEX.md) |
| ¿Cómo instalo? | [INSTALLATION.md](./INSTALLATION.md) |
| ¿Cómo funciona? | [LOAD_TEST_README.md](./LOAD_TEST_README.md) |
| ¿Ejemplos de uso? | [EXAMPLES.md](./EXAMPLES.md) |

### Soporte

1. Ejecuta `./quick_start.sh` opción 5 (Verificar servicios)
2. Lee la sección de Troubleshooting correspondiente
3. Revisa los logs: `tail -f load_test_results_*/test.log`

---

## 🏆 Proyecto 3 - MLOps

**Universidad:** Pontificia Universidad Javeriana  
**Curso:** Operaciones de Machine Learning  
**Fecha:** Noviembre 2025

---

## 🚀 Comienza Ahora

```bash
# Paso 1: Dar permisos
chmod +x *.sh

# Paso 2: Ejecutar menú
./quick_start.sh

# Paso 3: Seleccionar opción 2 (prueba pequeña)
# → 10 usuarios, 30 segundos

# Paso 4: Si todo OK, opción 1 (análisis completo)
# → Análisis de ~30 minutos
```

---

**¿Listo? ¡Empieza con `./quick_start.sh`! 🎉**
