# 📦 Paquete de Scripts de Análisis de Carga

## 🎯 Resumen Ejecutivo

Este paquete contiene scripts automatizados para realizar análisis completo de pruebas de carga con Locust en Kubernetes para el Proyecto 3 de MLOps.

---

## 📁 Archivos Incluidos

### 1. **`quick_start.sh`** ⭐ *INICIO AQUÍ*
**Menú interactivo principal** - La forma más fácil de empezar.

```bash
chmod +x quick_start.sh
./quick_start.sh
```

**Opciones del menú:**
- 1️⃣ Análisis completo automatizado (~20-30 min)
- 2️⃣ Prueba individual personalizable
- 3️⃣ Captura de dashboards de Grafana
- 4️⃣ Ver URLs de servicios
- 5️⃣ Verificar estado de servicios
- 6️⃣ Leer documentación completa

---

### 2. **`load_test_analysis.sh`** 
**Script principal** - Análisis completo automatizado.

Ejecuta el proceso completo:
1. ✅ Pruebas progresivas: 10, 25, 50, 100, 200 usuarios
2. ✅ Captura métricas K8s y Prometheus
3. ✅ Escala a 2 réplicas
4. ✅ Compara 1 vs 2 réplicas
5. ✅ Genera reporte en Markdown
6. ✅ Restaura configuración

```bash
./load_test_analysis.sh
```

**Resultados:** Carpeta `load_test_results_YYYYMMDD_HHMMSS/`

---

### 3. **`run_single_test.sh`**
**Pruebas individuales** - Para testing manual o ajustes.

```bash
./run_single_test.sh <usuarios> [segundos]

# Ejemplos:
./run_single_test.sh 10      # 10 usuarios, 60s
./run_single_test.sh 50 120  # 50 usuarios, 120s
```

**Características:**
- ✅ Verifica servicios antes de iniciar
- ✅ Barra de progreso en tiempo real
- ✅ Resultados inmediatos
- ✅ Indicador de éxito/fallo

---

### 4. **`capture_grafana.sh`**
**Captura de Grafana** - Extrae información de dashboards.

```bash
./capture_grafana.sh
```

**Genera:**
- Lista de dashboards disponibles
- Metadata en JSON
- Instrucciones para capturas de pantalla

---

### 5. **`LOAD_TEST_README.md`**
**Documentación completa** - Guía detallada de uso.

**Contenido:**
- 📖 Instrucciones paso a paso
- 🔧 Configuración y personalización
- 📊 Interpretación de resultados
- 🐛 Troubleshooting
- 💡 Best practices
- 📈 Análisis avanzado

---

## 🚀 Inicio Rápido

### Opción 1: Menú Interactivo (Recomendado)

```bash
# Dar permisos (solo primera vez)
chmod +x *.sh

# Ejecutar menú interactivo
./quick_start.sh
```

### Opción 2: Análisis Completo Directo

```bash
# Ejecutar análisis completo sin menú
./load_test_analysis.sh
```

### Opción 3: Prueba Individual

```bash
# Prueba rápida con 25 usuarios
./run_single_test.sh 25
```

---

## 📋 Prerequisitos

Antes de empezar, instala:

```bash
# En macOS:
brew install hudochenkov/sshpass/sshpass  # Requerido
brew install jq                            # Recomendado
brew install bc                            # Opcional
```

**Servicios necesarios (en la VM):**
- API en puerto 8001
- Locust en puerto 8004
- Grafana en puerto 3010
- Prometheus en puerto 3011

---

## 🎯 ¿Qué Script Usar?

### Si es tu primera vez → `quick_start.sh`
Menú interactivo con todas las opciones.

### Si quieres el análisis completo → `load_test_analysis.sh`
Análisis automatizado de 20-30 minutos.

### Si quieres probar algo rápido → `run_single_test.sh`
Prueba individual de 1-5 minutos.

### Si necesitas info de Grafana → `capture_grafana.sh`
Extrae metadata de dashboards.

### Si tienes dudas → `LOAD_TEST_README.md`
Documentación completa con ejemplos.

---

## 📊 Resultados Esperados

### Del Análisis Completo (`load_test_analysis.sh`)

```
load_test_results_YYYYMMDD_HHMMSS/
├── LOAD_TEST_REPORT.md           ← Reporte principal con tablas
├── test.log                      ← Log completo
├── metrics/
│   ├── *_stats.json             ← Estadísticas de Locust
│   ├── *_k8s_metrics.txt        ← Métricas de Kubernetes
│   └── *_prometheus_metrics.json ← Métricas de Prometheus
└── logs/                         ← Logs detallados
```

### De Pruebas Individuales (`run_single_test.sh`)

**Output en terminal:**
- Total de requests
- Tasa de error
- Latencias (min/avg/max/median)
- RPS (requests por segundo)
- Indicador de éxito ✓ o fallo ✗

---

## 🔑 Credenciales

### VM
- **Host:** 10.43.100.87
- **Usuario:** estudiante
- **Password:** Fl4m3nc0*15*

### Grafana
- **URL:** http://10.43.100.87:3010
- **Usuario:** admin
- **Password:** admin123

---

## 📈 Métricas Clave

| Métrica | Descripción | Objetivo |
|---------|-------------|----------|
| **Total Requests** | Peticiones totales | > 1000 |
| **Error %** | Tasa de error | < 1% |
| **Avg Response** | Latencia promedio | < 100ms |
| **P95** | 95% bajo este tiempo | < 200ms |
| **P99** | 99% bajo este tiempo | < 500ms |
| **RPS** | Requests/segundo | > 10 |

---

## 🐛 Problemas Comunes

### "sshpass: command not found"
```bash
brew install hudochenkov/sshpass/sshpass
```

### "Cannot connect to API"
```bash
# Verificar servicios
curl http://10.43.100.87:8001/health
curl http://10.43.100.87:8004
```

### "jq: command not found"
```bash
brew install jq  # No es crítico pero mejora el análisis
```

### Scripts no son ejecutables
```bash
chmod +x *.sh
```

---

## 📞 Ayuda

1. **Ejecuta el menú interactivo:**
   ```bash
   ./quick_start.sh
   ```
   
2. **Lee la documentación completa:**
   ```bash
   less LOAD_TEST_README.md
   # o
   cat LOAD_TEST_README.md
   ```

3. **Verifica el estado:**
   En el menú, selecciona opción 5

4. **Revisa los logs:**
   ```bash
   tail -f load_test_results_*/test.log
   ```

---

## 🔗 Enlaces Rápidos

- **Locust:** http://10.43.100.87:8004
- **API Docs:** http://10.43.100.87:8001/docs
- **Grafana:** http://10.43.100.87:3010
- **Prometheus:** http://10.43.100.87:3011

---

## ✨ Tips

1. **Empieza con el menú interactivo** (`quick_start.sh`)
2. **Haz una prueba individual primero** para verificar que todo funciona
3. **Ejecuta el análisis completo** cuando tengas 30 minutos libres
4. **Revisa Grafana durante las pruebas** para ver métricas en tiempo real
5. **Lee el reporte generado** para el análisis detallado

---

## 📝 Checklist de Ejecución

Antes de ejecutar el análisis completo:

- [ ] Herramientas instaladas (sshpass, jq, bc)
- [ ] Servicios verificados (API, Locust)
- [ ] Conexión SSH a la VM funcional
- [ ] Tiempo disponible (~30 minutos)
- [ ] Grafana abierto en navegador (opcional)

---

**¡Todo listo! Ejecuta `./quick_start.sh` para empezar 🚀**

---

*Proyecto 3 - MLOps*  
*Pontificia Universidad Javeriana*  
*Noviembre 2025*
