#!/usr/bin/env bash
#
# Script para capturar screenshots de Grafana
# Requiere: curl, jq (opcional)
#

set -euo pipefail

# Configuración
GRAFANA_URL="http://10.43.100.87:3010"
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin123"
OUTPUT_DIR="./grafana_screenshots"

# Colores
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Crear directorio
mkdir -p "$OUTPUT_DIR"

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}  Captura de Dashboards de Grafana${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Verificar Grafana
echo -e "${YELLOW}Verificando Grafana...${NC}"
STATUS=$(curl -s -o /dev/null -w "%{http_code}" -u "${GRAFANA_USER}:${GRAFANA_PASSWORD}" "${GRAFANA_URL}/api/health" || echo "000")

if [ "$STATUS" = "200" ]; then
    echo -e "${GREEN}✓${NC} Grafana disponible"
else
    echo -e "${RED}✗${NC} Grafana no disponible (HTTP ${STATUS})"
    exit 1
fi

echo ""

# Obtener lista de dashboards
echo -e "${YELLOW}Obteniendo lista de dashboards...${NC}"
DASHBOARDS=$(curl -s -u "${GRAFANA_USER}:${GRAFANA_PASSWORD}" \
    "${GRAFANA_URL}/api/search?type=dash-db")

if command -v jq &> /dev/null; then
    DASHBOARD_COUNT=$(echo "$DASHBOARDS" | jq '. | length')
    echo -e "${GREEN}✓${NC} Encontrados ${DASHBOARD_COUNT} dashboards"
    echo ""
    
    # Guardar información de dashboards
    DASHBOARD_INFO="${OUTPUT_DIR}/dashboards_info.txt"
    {
        echo "=== DASHBOARDS DISPONIBLES ==="
        echo "Fecha: $(date)"
        echo ""
        echo "$DASHBOARDS" | jq -r '.[] | "- \(.title) (UID: \(.uid))"'
    } > "$DASHBOARD_INFO"
    
    echo -e "${BLUE}Dashboards:${NC}"
    echo "$DASHBOARDS" | jq -r '.[] | "  - \(.title)"'
    echo ""
    
    # Guardar JSON completo
    echo "$DASHBOARDS" | jq '.' > "${OUTPUT_DIR}/dashboards.json"
    echo -e "${GREEN}✓${NC} Información guardada en: ${DASHBOARD_INFO}"
    
else
    echo -e "${YELLOW}⚠ jq no disponible - Guardando JSON crudo${NC}"
    echo "$DASHBOARDS" > "${OUTPUT_DIR}/dashboards.json"
fi

echo ""

# Nota sobre capturas
cat <<EOF
${YELLOW}NOTA:${NC} Para capturar screenshots de los dashboards, puedes:

1. ${BLUE}Usar la API de Grafana con render:${NC}
   curl -u ${GRAFANA_USER}:${GRAFANA_PASSWORD} \\
     "${GRAFANA_URL}/render/d/<dashboard-uid>/dashboard-name?orgId=1&from=now-1h&to=now&width=1920&height=1080" \\
     -o screenshot.png

2. ${BLUE}Usar Playwright/Puppeteer (requiere Node.js):${NC}
   npm install -g @playwright/test
   # Crear script de captura

3. ${BLUE}Captura manual:${NC}
   - Abrir ${GRAFANA_URL}
   - Navegar a cada dashboard
   - Usar herramienta de captura de pantalla

${BLUE}URLs de Grafana:${NC}
  - Home: ${GRAFANA_URL}
  - API: ${GRAFANA_URL}/api/health
  - Dashboards: ${GRAFANA_URL}/dashboards

EOF

echo -e "${GREEN}✓ Información de dashboards guardada en: ${OUTPUT_DIR}${NC}"
echo ""
