#!/usr/bin/env bash
#
# Script de Inicio Rápido - Análisis de Carga
# Menú interactivo para ejecutar las diferentes pruebas
#

set -euo pipefail

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
DIM='\033[2m'
NC='\033[0m'

# Banner
show_banner() {
    clear
    echo -e "${CYAN}"
    cat << "EOF"
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║     📊  ANÁLISIS DE PRUEBAS DE CARGA - PROYECTO 3 MLOPS      ║
║                                                                ║
║     Pontificia Universidad Javeriana                           ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝
EOF
    echo -e "${NC}\n"
}

# Menú principal
show_menu() {
    echo -e "${BLUE}Selecciona una opción:${NC}\n"
    echo -e "  ${GREEN}1)${NC} Ejecutar análisis completo automatizado ${DIM}(~20-30 min)${NC}"
    echo -e "  ${GREEN}2)${NC} Ejecutar prueba individual"
    echo -e "  ${GREEN}3)${NC} Capturar información de Grafana"
    echo -e "  ${GREEN}4)${NC} Ver URLs de servicios"
    echo -e "  ${GREEN}5)${NC} Verificar estado de servicios"
    echo -e "  ${GREEN}6)${NC} Leer documentación"
    echo -e "  ${GREEN}0)${NC} Salir"
    echo ""
}

# Verificar prerequisitos
check_prereqs() {
    local missing=0
    
    echo -e "${YELLOW}Verificando prerequisitos...${NC}"
    
    if ! command -v sshpass &> /dev/null; then
        echo -e "${RED}✗${NC} sshpass no instalado"
        echo -e "  Instala con: ${CYAN}brew install hudochenkov/sshpass/sshpass${NC}"
        missing=1
    else
        echo -e "${GREEN}✓${NC} sshpass instalado"
    fi
    
    if ! command -v curl &> /dev/null; then
        echo -e "${RED}✗${NC} curl no instalado"
        missing=1
    else
        echo -e "${GREEN}✓${NC} curl instalado"
    fi
    
    if ! command -v jq &> /dev/null; then
        echo -e "${YELLOW}⚠${NC} jq no instalado (opcional pero recomendado)"
        echo -e "  Instala con: ${CYAN}brew install jq${NC}"
    else
        echo -e "${GREEN}✓${NC} jq instalado"
    fi
    
    if ! command -v bc &> /dev/null; then
        echo -e "${YELLOW}⚠${NC} bc no instalado (opcional)"
        echo -e "  Instala con: ${CYAN}brew install bc${NC}"
    else
        echo -e "${GREEN}✓${NC} bc instalado"
    fi
    
    echo ""
    
    if [ $missing -eq 1 ]; then
        echo -e "${RED}Faltan herramientas requeridas. Instálalas antes de continuar.${NC}"
        return 1
    fi
    
    return 0
}

# Verificar servicios
check_services() {
    echo -e "${YELLOW}Verificando servicios...${NC}\n"
    
    local api_status=$(curl -s -o /dev/null -w "%{http_code}" "http://10.43.100.87:8001/health" 2>/dev/null || echo "000")
    local locust_status=$(curl -s -o /dev/null -w "%{http_code}" "http://10.43.100.87:8004" 2>/dev/null || echo "000")
    local grafana_status=$(curl -s -o /dev/null -w "%{http_code}" "http://10.43.100.87:3010" 2>/dev/null || echo "000")
    local streamlit_status=$(curl -s -o /dev/null -w "%{http_code}" "http://10.43.100.87:8003" 2>/dev/null || echo "000")
    
    printf "%-20s" "API:"
    [ "$api_status" = "200" ] && echo -e "${GREEN}✓ Disponible${NC}" || echo -e "${RED}✗ No disponible (HTTP ${api_status})${NC}"
    
    printf "%-20s" "Locust:"
    [ "$locust_status" = "200" ] && echo -e "${GREEN}✓ Disponible${NC}" || echo -e "${RED}✗ No disponible (HTTP ${locust_status})${NC}"
    
    printf "%-20s" "Grafana:"
    [ "$grafana_status" = "200" ] && echo -e "${GREEN}✓ Disponible${NC}" || echo -e "${RED}✗ No disponible (HTTP ${grafana_status})${NC}"
    
    printf "%-20s" "Streamlit:"
    [ "$streamlit_status" = "200" ] && echo -e "${GREEN}✓ Disponible${NC}" || echo -e "${RED}✗ No disponible (HTTP ${streamlit_status})${NC}"
    
    echo ""
}

# Mostrar URLs
show_urls() {
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  URLs de Servicios${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    echo -e "${CYAN}Aplicaciones:${NC}"
    echo -e "  API:        http://10.43.100.87:8001"
    echo -e "  API Docs:   http://10.43.100.87:8001/docs"
    echo -e "  Streamlit:  http://10.43.100.87:8003"
    echo -e "  Locust:     http://10.43.100.87:8004"
    echo ""
    echo -e "${CYAN}Monitoreo:${NC}"
    echo -e "  Grafana:    http://10.43.100.87:3010 (admin/admin123)"
    echo -e "  Prometheus: http://10.43.100.87:3011"
    echo ""
    echo -e "${CYAN}VM SSH:${NC}"
    echo -e "  Host:       10.43.100.87"
    echo -e "  Usuario:    estudiante"
    echo -e "  Comando:    ssh estudiante@10.43.100.87"
    echo ""
}

# Opción 1: Análisis completo
run_full_analysis() {
    show_banner
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  Análisis Completo Automatizado${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    echo -e "${YELLOW}Este proceso ejecutará:${NC}"
    echo -e "  1. Pruebas con 10, 25, 50, 100, 200 usuarios (1 réplica)"
    echo -e "  2. Captura de métricas de Kubernetes y Prometheus"
    echo -e "  3. Escalado a 2 réplicas"
    echo -e "  4. Prueba con 100 usuarios (2 réplicas)"
    echo -e "  5. Generación de reporte completo"
    echo -e "  6. Restauración a configuración original"
    echo ""
    echo -e "${CYAN}Duración estimada: 20-30 minutos${NC}"
    echo ""
    
    read -p "¿Continuar? (y/n): " confirm
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo "Operación cancelada."
        return
    fi
    
    echo ""
    ./load_test_analysis.sh
    
    echo ""
    read -p "Presiona Enter para continuar..."
}

# Opción 2: Prueba individual
run_single_test() {
    show_banner
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  Prueba Individual${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    echo -e "${YELLOW}Ejemplos de configuración:${NC}"
    echo -e "  - Prueba rápida:  10 usuarios, 30 segundos"
    echo -e "  - Prueba normal:  50 usuarios, 60 segundos"
    echo -e "  - Prueba larga:   100 usuarios, 120 segundos"
    echo ""
    
    read -p "Número de usuarios: " users
    read -p "Duración en segundos [60]: " duration
    duration=${duration:-60}
    
    if ! [[ "$users" =~ ^[0-9]+$ ]] || [ "$users" -lt 1 ]; then
        echo -e "${RED}Error: Número de usuarios inválido${NC}"
        read -p "Presiona Enter para continuar..."
        return
    fi
    
    echo ""
    ./run_single_test.sh "$users" "$duration"
    
    echo ""
    read -p "Presiona Enter para continuar..."
}

# Opción 3: Capturar Grafana
capture_grafana() {
    show_banner
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  Captura de Dashboards de Grafana${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    ./capture_grafana.sh
    
    echo ""
    read -p "Presiona Enter para continuar..."
}

# Opción 4: Mostrar URLs
show_urls_menu() {
    show_banner
    show_urls
    read -p "Presiona Enter para continuar..."
}

# Opción 5: Verificar servicios
check_services_menu() {
    show_banner
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  Estado de Servicios${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    check_prereqs
    echo ""
    check_services
    
    read -p "Presiona Enter para continuar..."
}

# Opción 6: Documentación
show_docs() {
    show_banner
    
    if [ -f "LOAD_TEST_README.md" ]; then
        if command -v less &> /dev/null; then
            less LOAD_TEST_README.md
        else
            cat LOAD_TEST_README.md
            echo ""
            read -p "Presiona Enter para continuar..."
        fi
    else
        echo -e "${RED}Error: Archivo LOAD_TEST_README.md no encontrado${NC}"
        read -p "Presiona Enter para continuar..."
    fi
}

# Loop principal
main() {
    # Verificar prerequisitos al inicio
    show_banner
    if ! check_prereqs; then
        echo ""
        read -p "Presiona Enter para salir..."
        exit 1
    fi
    
    while true; do
        show_banner
        show_menu
        
        read -p "Opción: " choice
        
        case $choice in
            1)
                run_full_analysis
                ;;
            2)
                run_single_test
                ;;
            3)
                capture_grafana
                ;;
            4)
                show_urls_menu
                ;;
            5)
                check_services_menu
                ;;
            6)
                show_docs
                ;;
            0)
                echo -e "\n${GREEN}¡Hasta luego!${NC}\n"
                exit 0
                ;;
            *)
                echo -e "\n${RED}Opción inválida. Intenta de nuevo.${NC}"
                sleep 2
                ;;
        esac
    done
}

# Ejecutar
main
