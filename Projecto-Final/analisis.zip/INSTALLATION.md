# 🔧 Instalación y Preparación

Guía completa para preparar tu entorno antes de ejecutar los scripts de análisis de carga.

---

## 📦 Archivos del Paquete

Tu paquete debe contener estos archivos:

```
load_test_scripts/
├── START_HERE.md              ← Lee este primero
├── LOAD_TEST_README.md        ← Documentación completa
├── EXAMPLES.md                ← Ejemplos prácticos
├── INSTALLATION.md            ← Este archivo
├── quick_start.sh             ⭐ Menú interactivo
├── load_test_analysis.sh      ⭐ Análisis completo
├── run_single_test.sh         ⭐ Pruebas individuales
└── capture_grafana.sh         ⭐ Captura de Grafana
```

---

## 🚀 Instalación Rápida

### Para macOS

```bash
# 1. Instalar Homebrew (si no lo tienes)
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# 2. Instalar herramientas requeridas
brew install hudochenkov/sshpass/sshpass

# 3. Instalar herramientas opcionales (recomendadas)
brew install jq bc

# 4. Verificar instalación
sshpass -V
jq --version
bc --version

# 5. Dar permisos a los scripts
cd load_test_scripts/
chmod +x *.sh

# 6. Ejecutar
./quick_start.sh
```

### Para Linux (Ubuntu/Debian)

```bash
# 1. Actualizar sistema
sudo apt update

# 2. Instalar herramientas requeridas
sudo apt install -y sshpass

# 3. Instalar herramientas opcionales
sudo apt install -y jq bc curl

# 4. Verificar instalación
sshpass -V
jq --version
bc --version

# 5. Dar permisos a los scripts
cd load_test_scripts/
chmod +x *.sh

# 6. Ejecutar
./quick_start.sh
```

### Para Linux (Rocky/CentOS/RHEL)

```bash
# 1. Actualizar sistema
sudo dnf update -y

# 2. Habilitar EPEL
sudo dnf install -y epel-release

# 3. Instalar herramientas requeridas
sudo dnf install -y sshpass

# 4. Instalar herramientas opcionales
sudo dnf install -y jq bc curl

# 5. Verificar instalación
sshpass -V
jq --version
bc --version

# 6. Dar permisos a los scripts
cd load_test_scripts/
chmod +x *.sh

# 7. Ejecutar
./quick_start.sh
```

---

## 🔍 Verificación de Prerequisitos

### Script de Verificación Automática

Los scripts incluyen verificación automática, pero puedes verificar manualmente:

```bash
# Verificar sshpass (REQUERIDO)
which sshpass
sshpass -V

# Verificar curl (REQUERIDO)
which curl
curl --version

# Verificar jq (OPCIONAL pero recomendado)
which jq
jq --version

# Verificar bc (OPCIONAL)
which bc
bc --version
```

### Resultado Esperado

```bash
✓ sshpass instalado
✓ curl instalado
✓ jq instalado
✓ bc instalado
```

---

## 🌐 Verificación de Conectividad

### Verificar Acceso a la VM

```bash
# Probar conexión SSH
ssh estudiante@10.43.100.87
# Password: Fl4m3nc0*15*

# Si funciona, salir
exit
```

### Verificar Servicios Web

```bash
# API
curl -s http://10.43.100.87:8001/health | jq '.'
# Esperado: {"status": "healthy", ...}

# Locust
curl -s -o /dev/null -w "%{http_code}\n" http://10.43.100.87:8004
# Esperado: 200

# Grafana
curl -s -o /dev/null -w "%{http_code}\n" http://10.43.100.87:3010
# Esperado: 200

# Prometheus
curl -s -o /dev/null -w "%{http_code}\n" http://10.43.100.87:3011
# Esperado: 200
```

### Script de Verificación Completa

Crear archivo `verify_setup.sh`:

```bash
#!/bin/bash

echo "Verificando configuración..."
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Check tools
echo "=== Herramientas ==="
for tool in sshpass curl jq bc; do
    if command -v $tool &> /dev/null; then
        echo -e "${GREEN}✓${NC} $tool instalado"
    else
        if [ "$tool" = "sshpass" ] || [ "$tool" = "curl" ]; then
            echo -e "${RED}✗${NC} $tool NO instalado (REQUERIDO)"
        else
            echo -e "${YELLOW}⚠${NC} $tool NO instalado (opcional)"
        fi
    fi
done

echo ""
echo "=== Conectividad SSH ==="
if sshpass -p "Fl4m3nc0*15*" ssh -o StrictHostKeyChecking=no \
    -o UserKnownHostsFile=/dev/null \
    -o ConnectTimeout=5 \
    -o LogLevel=ERROR \
    estudiante@10.43.100.87 "echo OK" 2>/dev/null; then
    echo -e "${GREEN}✓${NC} SSH a VM funcionando"
else
    echo -e "${RED}✗${NC} SSH a VM NO funciona"
fi

echo ""
echo "=== Servicios Web ==="
services=(
    "API:http://10.43.100.87:8001/health"
    "Locust:http://10.43.100.87:8004"
    "Grafana:http://10.43.100.87:3010"
    "Prometheus:http://10.43.100.87:3011"
)

for service in "${services[@]}"; do
    name="${service%%:*}"
    url="${service#*:}"
    status=$(curl -s -o /dev/null -w "%{http_code}" "$url" 2>/dev/null || echo "000")
    
    if [ "$status" = "200" ]; then
        echo -e "${GREEN}✓${NC} $name disponible"
    else
        echo -e "${RED}✗${NC} $name NO disponible (HTTP $status)"
    fi
done

echo ""
echo "Verificación completada"
```

Ejecutar:

```bash
chmod +x verify_setup.sh
./verify_setup.sh
```

---

## 🔧 Configuración Avanzada

### Configurar SSH sin Password (Opcional)

Para evitar escribir el password cada vez:

```bash
# 1. Generar clave SSH (si no tienes una)
ssh-keygen -t rsa -b 4096 -C "tu_email@example.com"
# Presiona Enter para aceptar ubicación por defecto
# Presiona Enter 2 veces para sin passphrase

# 2. Copiar clave a la VM
ssh-copy-id estudiante@10.43.100.87
# Ingresa password: Fl4m3nc0*15*

# 3. Probar
ssh estudiante@10.43.100.87
# Debería entrar sin pedir password
```

**Nota:** Si configuras esto, los scripts seguirán funcionando pero ya no necesitarás sshpass.

### Configurar Alias SSH (Opcional)

Agregar a `~/.ssh/config`:

```
Host proyecto3-vm
    HostName 10.43.100.87
    User estudiante
    StrictHostKeyChecking no
    UserKnownHostsFile /dev/null
```

Ahora puedes conectar con:

```bash
ssh proyecto3-vm
```

---

## 📋 Checklist de Preparación

Antes de ejecutar los scripts, verifica:

### Herramientas
- [ ] sshpass instalado y funcional
- [ ] curl instalado
- [ ] jq instalado (opcional)
- [ ] bc instalado (opcional)

### Conectividad
- [ ] SSH a 10.43.100.87 funciona
- [ ] API responde en puerto 8001
- [ ] Locust responde en puerto 8004
- [ ] Grafana responde en puerto 3010
- [ ] Prometheus responde en puerto 3011

### Archivos
- [ ] Todos los archivos .sh descargados
- [ ] Permisos de ejecución configurados (`chmod +x *.sh`)
- [ ] Documentación disponible (*.md)

### Servicios en VM
- [ ] Deployment de API corriendo en Kubernetes
- [ ] Locust corriendo
- [ ] Grafana configurado
- [ ] Prometheus scrapeando métricas

---

## 🐛 Troubleshooting de Instalación

### Error: "sshpass: command not found"

**En macOS:**
```bash
brew install hudochenkov/sshpass/sshpass
```

**En Linux:**
```bash
sudo apt install sshpass     # Ubuntu/Debian
sudo dnf install sshpass     # Rocky/CentOS/RHEL
```

### Error: "brew: command not found" (macOS)

```bash
# Instalar Homebrew
/bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

# Seguir las instrucciones post-instalación
```

### Error: "Permission denied" al ejecutar scripts

```bash
# Dar permisos de ejecución
chmod +x *.sh

# Verificar
ls -l *.sh
# Deberías ver -rwxr-xr-x
```

### Error: "Connection refused" a servicios

**Verificar que los servicios estén corriendo en la VM:**

```bash
# Conectar a VM
ssh estudiante@10.43.100.87

# Verificar pods
microk8s kubectl get pods -n apps

# Verificar servicios
microk8s kubectl get svc -n apps

# Ver port-forwards activos
ps aux | grep "port-forward"
```

### Error: "Host key verification failed"

```bash
# Limpiar host key
ssh-keygen -R 10.43.100.87

# O desactivar verificación (menos seguro)
ssh -o StrictHostKeyChecking=no estudiante@10.43.100.87
```

---

## 🎯 Siguiente Paso

Una vez que todo esté instalado y verificado:

```bash
# Ejecutar el menú interactivo
./quick_start.sh
```

O lee los archivos de documentación:

- **START_HERE.md** - Resumen ejecutivo
- **LOAD_TEST_README.md** - Documentación completa
- **EXAMPLES.md** - Ejemplos prácticos

---

## 📞 Ayuda Adicional

Si sigues teniendo problemas después de seguir esta guía:

1. Ejecuta el script de verificación:
   ```bash
   ./verify_setup.sh
   ```

2. Revisa los errores específicos en la salida

3. Consulta la sección de Troubleshooting en `LOAD_TEST_README.md`

4. Verifica los servicios en la VM directamente

---

**¡Listo para empezar! 🚀**

Una vez que todo esté ✓, ejecuta:

```bash
./quick_start.sh
```

---

*Proyecto 3 - MLOps*  
*Pontificia Universidad Javeriana*  
*Noviembre 2025*
