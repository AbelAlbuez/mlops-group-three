# 📊 Scripts de Análisis de Pruebas de Carga

Scripts automatizados para realizar análisis completo de pruebas de carga con Locust en Kubernetes.

## 📋 Contenido

- **`load_test_analysis.sh`**: Script principal - ejecuta análisis completo automatizado
- **`run_single_test.sh`**: Script auxiliar - ejecuta pruebas individuales
- **`capture_grafana.sh`**: Script para capturar información de dashboards de Grafana

---

## 🚀 Inicio Rápido

### Prerequisitos

```bash
# Instalar herramientas necesarias
brew install hudochenkov/sshpass/sshpass
brew install jq  # Opcional pero recomendado
brew install bc  # Para cálculos
```

### Ejecución Completa

```bash
# Dar permisos de ejecución
chmod +x load_test_analysis.sh
chmod +x run_single_test.sh
chmod +x capture_grafana.sh

# Ejecutar análisis completo (recomendado)
./load_test_analysis.sh
```

**El script completo ejecuta:**

1. ✅ Pruebas progresivas: 10, 25, 50, 100, 200 usuarios (1 réplica)
2. ✅ Captura métricas de Kubernetes después de cada prueba
3. ✅ Captura métricas de Prometheus
4. ✅ Escala a 2 réplicas
5. ✅ Repite prueba de 100 usuarios con 2 réplicas
6. ✅ Compara resultados 1 vs 2 réplicas
7. ✅ Genera reporte completo en Markdown
8. ✅ Restaura configuración original

**Duración estimada:** ~20-30 minutos

---

## 📖 Scripts Individuales

### 1. Script Principal: `load_test_analysis.sh`

Ejecuta el análisis completo automatizado.

```bash
./load_test_analysis.sh
```

**Resultados generados:**

```
load_test_results_YYYYMMDD_HHMMSS/
├── LOAD_TEST_REPORT.md          # Reporte principal con tablas y análisis
├── test.log                     # Log completo de la ejecución
├── logs/                        # Logs detallados
├── metrics/                     # Métricas capturadas
│   ├── test_10_users_stats.json
│   ├── test_10_users_before_k8s_metrics.txt
│   ├── test_10_users_after_k8s_metrics.txt
│   ├── test_10_users_prometheus_metrics.json
│   └── ... (similar para cada prueba)
└── screenshots/                 # Para capturas manuales
```

**El reporte incluye:**

- Tabla comparativa de todas las pruebas
- Comparación 1 vs 2 réplicas
- Métricas: requests, failures, latencias (min/avg/max/median), RPS, error %
- Análisis de resultados (si jq está instalado)
- Recomendaciones de configuración

---

### 2. Script Auxiliar: `run_single_test.sh`

Para ejecutar pruebas individuales manualmente.

```bash
# Sintaxis
./run_single_test.sh <num_usuarios> [duracion_segundos]

# Ejemplos
./run_single_test.sh 10          # 10 usuarios, 60 segundos
./run_single_test.sh 50 120      # 50 usuarios, 120 segundos
./run_single_test.sh 100 300     # 100 usuarios, 5 minutos
```

**Características:**

- ✅ Verifica disponibilidad de API y Locust
- ✅ Inicia prueba con configuración especificada
- ✅ Muestra barra de progreso en tiempo real
- ✅ Presenta resultados al finalizar
- ✅ Indica si la prueba fue exitosa

**Salida de ejemplo:**

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Prueba de Carga - 50 usuarios por 60s
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Verificando servicios...
✓ API disponible
✓ Locust disponible

...

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  RESULTADOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Total Requests:   2834
  Total Failures:   0 (0.00%)
  Requests/sec:     47.23

  Response Times:
    Min:     12ms
    Avg:     37ms
    Median:  35ms
    Max:     110ms

✓ Prueba exitosa - Sin errores
```

---

### 3. Script de Grafana: `capture_grafana.sh`

Captura información de dashboards de Grafana.

```bash
./capture_grafana.sh
```

**Genera:**

- `grafana_screenshots/dashboards_info.txt`: Lista de dashboards disponibles
- `grafana_screenshots/dashboards.json`: Metadata completa en JSON

**Nota:** Para capturas de pantalla reales, sigue las instrucciones que muestra el script.

---

## 🔧 Configuración

### Variables Principales (en `load_test_analysis.sh`)

```bash
# Configuración de VM
VM_HOST="10.43.100.87"
VM_USER="estudiante"
VM_PASSWORD="Fl4m3nc0*15*"

# URLs de servicios
LOCUST_URL="http://${VM_HOST}:8004"
API_URL="http://${VM_HOST}:8001"
GRAFANA_URL="http://${VM_HOST}:3010"
PROMETHEUS_URL="http://${VM_HOST}:3011"

# Configuración de pruebas
TEST_USERS=(10 25 50 100 200)  # Usuarios por prueba
SPAWN_RATE=5                    # Usuarios/segundo
TEST_DURATION=60                # Segundos por prueba

# Kubernetes
K8S_NAMESPACE="apps"
K8S_DEPLOYMENT="api"
```

### Personalizar Pruebas

Para cambiar los usuarios o duración, edita las variables en el script:

```bash
# Ejemplo: Pruebas más largas con más usuarios
TEST_USERS=(20 50 100 200 500)
TEST_DURATION=120  # 2 minutos por prueba
```

---

## 📊 Interpretación de Resultados

### Métricas Clave

1. **Total Requests**: Número total de peticiones realizadas
2. **Total Failures**: Peticiones fallidas
3. **Error %**: Porcentaje de errores (objetivo: < 1%)
4. **Avg Response Time**: Latencia promedio (objetivo: < 100ms)
5. **P95/P99**: Percentiles (95% y 99% de requests bajo ese tiempo)
6. **RPS**: Requests por segundo (throughput)

### Criterios de Éxito

| Métrica | Excelente | Bueno | Aceptable | Malo |
|---------|-----------|-------|-----------|------|
| Error % | 0% | < 0.1% | < 1% | > 1% |
| Avg Response | < 50ms | < 100ms | < 200ms | > 200ms |
| P99 | < 100ms | < 200ms | < 500ms | > 500ms |

### Indicadores de Problemas

- **Error % creciente**: Sistema saturado, considerar escalar
- **Latencia > 200ms**: CPU o memoria insuficientes
- **RPS estancado**: Bottleneck en el sistema

---

## 🐛 Troubleshooting

### Error: "sshpass: command not found"

```bash
brew install hudochenkov/sshpass/sshpass
```

### Error: "Cannot connect to API"

1. Verifica que los servicios estén corriendo:
   ```bash
   curl http://10.43.100.87:8001/health
   curl http://10.43.100.87:8004
   ```

2. Verifica en la VM:
   ```bash
   ssh estudiante@10.43.100.87
   microk8s kubectl get pods -n apps
   ```

### Error: "jq: command not found"

No es crítico, pero instálalo para análisis detallado:

```bash
brew install jq
```

### Locust no inicia pruebas

1. Verifica que Locust esté en la UI: http://10.43.100.87:8004
2. Detén cualquier prueba en curso manualmente
3. Ejecuta el script de nuevo

### Kubernetes no responde

```bash
# Conectar a VM y verificar
ssh estudiante@10.43.100.87
microk8s status
microk8s kubectl get all -n apps
```

---

## 📈 Análisis Avanzado

### Consultas de Prometheus

Puedes ejecutar queries manuales en: http://10.43.100.87:3011

**Queries útiles:**

```promql
# Rate de predicciones
rate(predictions_total[1m])

# Latencia P95
histogram_quantile(0.95, rate(prediction_duration_seconds_bucket[1m]))

# Rate de errores
rate(prediction_errors_total[1m])

# CPU usage (si está configurado)
container_cpu_usage_seconds_total{namespace="apps"}
```

### Dashboards en Grafana

Accede a: http://10.43.100.87:3010

**Credenciales:**
- Usuario: `admin`
- Password: `admin123`

**Paneles recomendados:**
1. API Performance: Latencias, throughput, errores
2. Kubernetes Resources: CPU, memoria, pods
3. ML Model Metrics: Predicciones por modelo

---

## 📝 Ejemplos de Uso

### Caso 1: Análisis Completo Estándar

```bash
# Ejecutar análisis completo con configuración por defecto
./load_test_analysis.sh

# Resultados en: load_test_results_YYYYMMDD_HHMMSS/
# Ver reporte: cat load_test_results_*/LOAD_TEST_REPORT.md
```

### Caso 2: Prueba Rápida Individual

```bash
# Probar con 25 usuarios por 30 segundos
./run_single_test.sh 25 30

# Ver resultados en tiempo real en Locust UI
open http://10.43.100.87:8004
```

### Caso 3: Análisis de Escalado Manual

```bash
# 1. Escalar a 3 réplicas
ssh estudiante@10.43.100.87
microk8s kubectl scale deployment api -n apps --replicas=3

# 2. Ejecutar prueba
./run_single_test.sh 100 120

# 3. Capturar métricas manualmente
./capture_grafana.sh

# 4. Restaurar
microk8s kubectl scale deployment api -n apps --replicas=1
```

### Caso 4: Pruebas de Estrés

```bash
# Modificar TEST_USERS en load_test_analysis.sh
TEST_USERS=(50 100 200 400 800)
TEST_DURATION=120

# Ejecutar
./load_test_analysis.sh
```

---

## 📂 Estructura de Resultados

```
load_test_results_20251109_150000/
│
├── LOAD_TEST_REPORT.md                    # Reporte principal
├── test.log                               # Log de ejecución
│
├── metrics/
│   ├── test_10_users_stats.json          # Estadísticas Locust
│   ├── test_10_users_before_k8s_metrics.txt
│   ├── test_10_users_after_k8s_metrics.txt
│   ├── test_10_users_prometheus_metrics.json
│   │
│   ├── test_25_users_stats.json
│   ├── ...
│   │
│   ├── test_100_users_2replicas_stats.json  # Prueba con 2 réplicas
│   └── ...
│
├── logs/                                  # Logs detallados
└── screenshots/                           # Para capturas manuales
```

---

## 🎯 Best Practices

1. **Ejecuta durante horas de baja carga** para no afectar otros sistemas
2. **Revisa los logs** si hay comportamiento inesperado
3. **Compara resultados** entre diferentes ejecuciones
4. **Documenta cambios** en infraestructura que puedan afectar resultados
5. **Escala gradualmente** - no saltes de 10 a 1000 usuarios
6. **Monitorea recursos** en Grafana durante las pruebas

---

## 🔗 Enlaces Útiles

- **Locust UI**: http://10.43.100.87:8004
- **API**: http://10.43.100.87:8001
- **API Docs**: http://10.43.100.87:8001/docs
- **Streamlit**: http://10.43.100.87:8003
- **Grafana**: http://10.43.100.87:3010
- **Prometheus**: http://10.43.100.87:3011

---

## 📞 Soporte

Si encuentras problemas:

1. Revisa los logs en `load_test_results_*/test.log`
2. Verifica servicios en la VM
3. Consulta el troubleshooting en este README
4. Revisa los logs de Kubernetes:
   ```bash
   ssh estudiante@10.43.100.87
   microk8s kubectl logs -n apps deployment/api
   ```

---

**Última actualización:** Noviembre 2025
**Proyecto:** MLOps - Proyecto 3
**Universidad:** Pontificia Universidad Javeriana
