#!/usr/bin/env bash
#
# Script auxiliar para ejecutar pruebas individuales de carga
# Uso: ./run_single_test.sh <num_usuarios> [duracion_segundos]
#

set -euo pipefail

# Configuración
LOCUST_URL="http://10.43.100.87:8004"
API_URL="http://10.43.100.87:8001"
DEFAULT_DURATION=60
SPAWN_RATE=5

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

# Validar argumentos
if [ $# -lt 1 ]; then
    echo "Uso: $0 <num_usuarios> [duracion_segundos]"
    echo ""
    echo "Ejemplos:"
    echo "  $0 10          # 10 usuarios, 60 segundos"
    echo "  $0 50 120      # 50 usuarios, 120 segundos"
    exit 1
fi

NUM_USERS=$1
DURATION=${2:-$DEFAULT_DURATION}

echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${BLUE}  Prueba de Carga - ${NUM_USERS} usuarios por ${DURATION}s${NC}"
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""

# Verificar servicios
echo -e "${YELLOW}Verificando servicios...${NC}"

API_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "${API_URL}/health" || echo "000")
if [ "$API_STATUS" = "200" ]; then
    echo -e "${GREEN}✓${NC} API disponible"
else
    echo -e "${RED}✗${NC} API no disponible (HTTP ${API_STATUS})"
    exit 1
fi

LOCUST_STATUS=$(curl -s -o /dev/null -w "%{http_code}" "${LOCUST_URL}" || echo "000")
if [ "$LOCUST_STATUS" = "200" ]; then
    echo -e "${GREEN}✓${NC} Locust disponible"
else
    echo -e "${RED}✗${NC} Locust no disponible (HTTP ${LOCUST_STATUS})"
    exit 1
fi

echo ""

# Iniciar prueba
echo -e "${YELLOW}Iniciando prueba con ${NUM_USERS} usuarios...${NC}"

START_PAYLOAD=$(cat <<EOF
{
    "user_count": ${NUM_USERS},
    "spawn_rate": ${SPAWN_RATE},
    "host": "${API_URL}"
}
EOF
)

curl -s -X POST "${LOCUST_URL}/swarm" \
    -H "Content-Type: application/json" \
    -d "$START_PAYLOAD" > /dev/null

if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓${NC} Prueba iniciada"
else
    echo -e "${RED}✗${NC} Error al iniciar prueba"
    exit 1
fi

# Calcular tiempo total (incluyendo spawn)
SPAWN_TIME=$((NUM_USERS / SPAWN_RATE))
TOTAL_TIME=$((DURATION + SPAWN_TIME + 5))

echo ""
echo -e "${BLUE}Parámetros:${NC}"
echo -e "  Usuarios: ${NUM_USERS}"
echo -e "  Spawn rate: ${SPAWN_RATE} usuarios/segundo"
echo -e "  Tiempo de spawn: ~${SPAWN_TIME}s"
echo -e "  Duración del test: ${DURATION}s"
echo -e "  Tiempo total: ~${TOTAL_TIME}s"
echo ""

# Contador con barra de progreso
echo -e "${YELLOW}Ejecutando prueba...${NC}"
for ((i=1; i<=TOTAL_TIME; i++)); do
    PERCENT=$((i * 100 / TOTAL_TIME))
    BAR_LENGTH=$((PERCENT / 2))
    BAR=$(printf "%${BAR_LENGTH}s" | tr ' ' '█')
    EMPTY=$((50 - BAR_LENGTH))
    EMPTY_BAR=$(printf "%${EMPTY}s" | tr ' ' '░')
    
    echo -ne "\r[${BAR}${EMPTY_BAR}] ${PERCENT}% (${i}/${TOTAL_TIME}s)"
    sleep 1
done
echo ""

# Obtener estadísticas
echo ""
echo -e "${YELLOW}Obteniendo resultados...${NC}"

STATS=$(curl -s "${LOCUST_URL}/stats/requests")

# Detener el test
curl -s -X GET "${LOCUST_URL}/stop" > /dev/null
echo -e "${GREEN}✓${NC} Prueba detenida"

echo ""

# Mostrar resultados si jq está disponible
if command -v jq &> /dev/null; then
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${BLUE}  RESULTADOS${NC}"
    echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo ""
    
    TOTAL_REQUESTS=$(echo "$STATS" | jq -r '.stats[0].num_requests // 0')
    TOTAL_FAILURES=$(echo "$STATS" | jq -r '.stats[0].num_failures // 0')
    AVG_RESPONSE=$(echo "$STATS" | jq -r '.stats[0].avg_response_time // 0')
    MIN_RESPONSE=$(echo "$STATS" | jq -r '.stats[0].min_response_time // 0')
    MAX_RESPONSE=$(echo "$STATS" | jq -r '.stats[0].max_response_time // 0')
    MEDIAN_RESPONSE=$(echo "$STATS" | jq -r '.stats[0].median_response_time // 0')
    RPS=$(echo "$STATS" | jq -r '.stats[0].current_rps // 0')
    
    ERROR_PCT=0
    if [ "$TOTAL_REQUESTS" -gt 0 ]; then
        ERROR_PCT=$(echo "scale=2; ($TOTAL_FAILURES / $TOTAL_REQUESTS) * 100" | bc)
    fi
    
    echo -e "  ${BLUE}Total Requests:${NC}   ${TOTAL_REQUESTS}"
    echo -e "  ${BLUE}Total Failures:${NC}   ${TOTAL_FAILURES} (${ERROR_PCT}%)"
    echo -e "  ${BLUE}Requests/sec:${NC}     ${RPS}"
    echo ""
    echo -e "  ${BLUE}Response Times:${NC}"
    echo -e "    Min:     ${MIN_RESPONSE}ms"
    echo -e "    Avg:     ${AVG_RESPONSE}ms"
    echo -e "    Median:  ${MEDIAN_RESPONSE}ms"
    echo -e "    Max:     ${MAX_RESPONSE}ms"
    echo ""
    
    # Determinar resultado
    if [ "$TOTAL_FAILURES" -eq 0 ]; then
        echo -e "${GREEN}✓ Prueba exitosa - Sin errores${NC}"
    elif [ "$ERROR_PCT" == "0.00" ] || [ "${ERROR_PCT%.*}" -lt 1 ]; then
        echo -e "${YELLOW}⚠ Prueba aceptable - Pocos errores (${ERROR_PCT}%)${NC}"
    else
        echo -e "${RED}✗ Prueba con problemas - Tasa de error: ${ERROR_PCT}%${NC}"
    fi
    
else
    echo -e "${YELLOW}⚠ jq no disponible - Mostrando JSON crudo:${NC}"
    echo "$STATS" | python3 -m json.tool 2>/dev/null || echo "$STATS"
fi

echo ""
echo -e "${BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo -e "${GREEN}✓ Prueba completada${NC}"
echo ""
echo "Ver más detalles en: ${LOCUST_URL}"
echo ""
