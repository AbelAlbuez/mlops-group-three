# 💡 Ejemplos Prácticos de Uso

Guía con escenarios reales de uso de los scripts de análisis de carga.

---

## 📚 Tabla de Contenidos

1. [Primer Uso - Verificación Básica](#1-primer-uso---verificación-básica)
2. [Análisis Estándar para Proyecto](#2-análisis-estándar-para-proyecto)
3. [Testing Iterativo de Configuración](#3-testing-iterativo-de-configuración)
4. [Análisis de Escalado](#4-análisis-de-escalado)
5. [Pruebas de Estrés](#5-pruebas-de-estrés)
6. [Debug de Problemas de Performance](#6-debug-de-problemas-de-performance)
7. [Captura para Presentación](#7-captura-para-presentación)

---

## 1. Primer Uso - Verificación Básica

**Objetivo:** Verificar que todo funciona antes del análisis completo.

### Paso a Paso

```bash
# 1. Dar permisos (solo primera vez)
chmod +x *.sh

# 2. Ejecutar menú interactivo
./quick_start.sh
```

En el menú:
1. Selecciona opción `5` (Verificar estado de servicios)
2. Verifica que todos los servicios estén ✓
3. Selecciona opción `2` (Prueba individual)
4. Ingresa: `10` usuarios, `30` segundos

**Resultado esperado:**
```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  RESULTADOS
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

  Total Requests:   450
  Total Failures:   0 (0.00%)
  Requests/sec:     15

  Response Times:
    Min:     12ms
    Avg:     35ms
    Median:  33ms
    Max:     85ms

✓ Prueba exitosa - Sin errores
```

**Si todo está ✓** → Continúa con el análisis completo  
**Si hay errores ✗** → Revisa troubleshooting en README

---

## 2. Análisis Estándar para Proyecto

**Objetivo:** Ejecutar el análisis completo requerido para el proyecto.

### Comando

```bash
./load_test_analysis.sh
```

### ¿Qué hace?

1. **Fase 1 - Pruebas Progresivas (1 réplica):**
   - 10 usuarios × 60s
   - 25 usuarios × 60s
   - 50 usuarios × 60s
   - 100 usuarios × 60s
   - 200 usuarios × 60s

2. **Fase 2 - Escalado:**
   - Escala a 2 réplicas
   - 100 usuarios × 60s (repetición)

3. **Análisis:**
   - Compara 1 vs 2 réplicas
   - Genera reporte completo

### Timeline

```
00:00 - Inicio
00:05 - Prueba 10 usuarios
00:10 - Prueba 25 usuarios
00:15 - Prueba 50 usuarios
00:20 - Prueba 100 usuarios
00:25 - Prueba 200 usuarios
00:30 - Escalado a 2 réplicas
00:35 - Prueba 100 usuarios (2 réplicas)
00:40 - Generación de reporte
00:41 - ✓ Completado
```

### Durante la Ejecución

**Abre en navegador (opcional):**
- http://10.43.100.87:8004 → Ver Locust en tiempo real
- http://10.43.100.87:3010 → Ver Grafana durante las pruebas

### Resultado

```
load_test_results_20251109_150000/
├── LOAD_TEST_REPORT.md      ← Reporte principal
├── metrics/                 ← Todas las métricas
└── logs/                    ← Logs detallados
```

### ¿Qué Hacer con el Reporte?

```bash
# Ver el reporte
cat load_test_results_*/LOAD_TEST_REPORT.md

# O mejor, abrirlo en un editor de Markdown
code load_test_results_*/LOAD_TEST_REPORT.md
```

El reporte incluye:
- ✅ Tabla comparativa de todas las pruebas
- ✅ Comparación 1 vs 2 réplicas
- ✅ Análisis de resultados
- ✅ Recomendaciones

---

## 3. Testing Iterativo de Configuración

**Objetivo:** Probar diferentes configuraciones antes del análisis final.

### Escenario: Ajustar Spawn Rate

```bash
# Editar load_test_analysis.sh
nano load_test_analysis.sh

# Cambiar línea:
SPAWN_RATE=5    # Original
SPAWN_RATE=10   # Más rápido

# Ejecutar
./load_test_analysis.sh
```

### Escenario: Probar Solo Cargas Altas

```bash
# Editar load_test_analysis.sh
nano load_test_analysis.sh

# Cambiar línea:
TEST_USERS=(10 25 50 100 200)   # Original
TEST_USERS=(100 200 400)         # Solo cargas altas

# Ejecutar
./load_test_analysis.sh
```

### Escenario: Pruebas Más Largas

```bash
# Editar load_test_analysis.sh
nano load_test_analysis.sh

# Cambiar línea:
TEST_DURATION=60    # Original
TEST_DURATION=120   # 2 minutos por prueba

# Ejecutar
./load_test_analysis.sh
```

---

## 4. Análisis de Escalado

**Objetivo:** Comparar rendimiento con diferentes números de réplicas.

### Opción A: Manual con SSH

```bash
# Terminal 1: Conectar a VM
ssh estudiante@10.43.100.87
# Password: Fl4m3nc0*15*

# Escalar a diferentes réplicas
microk8s kubectl scale deployment api -n apps --replicas=1
microk8s kubectl rollout status deployment/api -n apps

# Terminal 2: Ejecutar prueba
./run_single_test.sh 100 120

# Repetir con 2, 3, 4 réplicas y comparar
```

### Opción B: Script Automatizado

Crear archivo `test_scaling.sh`:

```bash
#!/bin/bash
for replicas in 1 2 3 4; do
    echo "Testing with $replicas replicas..."
    
    # Escalar
    ssh estudiante@10.43.100.87 \
        "microk8s kubectl scale deployment api -n apps --replicas=$replicas"
    
    # Esperar
    sleep 15
    
    # Probar
    ./run_single_test.sh 100 120 > "results_${replicas}_replicas.txt"
    
    echo "Completed $replicas replicas"
done
```

### Analizar Resultados

```bash
# Ver todos los resultados
cat results_*_replicas.txt | grep -E "(Total Requests|Avg Response|Error)"
```

---

## 5. Pruebas de Estrés

**Objetivo:** Determinar el punto de quiebre del sistema.

### Encontrar Límite Superior

```bash
# Prueba progresiva manual
./run_single_test.sh 100   # ¿OK?
./run_single_test.sh 200   # ¿OK?
./run_single_test.sh 400   # ¿Empieza a fallar?
./run_single_test.sh 600   # ¿Más errores?
./run_single_test.sh 800   # ¿Saturado?
```

### Script de Stress Test

Crear `stress_test.sh`:

```bash
#!/bin/bash
# Prueba hasta que falle

for users in 50 100 200 400 800 1600; do
    echo "======================================"
    echo "Testing with $users users"
    echo "======================================"
    
    ./run_single_test.sh $users 60
    
    # Preguntar si continuar
    read -p "Continue to next level? (y/n): " continue
    if [[ ! $continue =~ ^[Yy]$ ]]; then
        break
    fi
    
    # Pausa entre pruebas
    echo "Cooling down for 30 seconds..."
    sleep 30
done

echo "Stress test completed!"
```

### Analizar Comportamiento

Observar en qué punto:
- Error % > 1%
- Latencia promedio > 200ms
- El sistema deja de responder

---

## 6. Debug de Problemas de Performance

**Objetivo:** Identificar por qué el sistema es lento.

### Paso 1: Baseline

```bash
# Establecer baseline con carga baja
./run_single_test.sh 10 60

# Guardar resultados
# Min: 15ms, Avg: 30ms, Max: 50ms
```

### Paso 2: Incrementar Gradualmente

```bash
# Aumentar hasta ver degradación
./run_single_test.sh 25 60   # Avg: 35ms
./run_single_test.sh 50 60   # Avg: 45ms  ← Empieza a subir
./run_single_test.sh 75 60   # Avg: 120ms ← Salto grande
```

### Paso 3: Investigar en Grafana

```bash
# Abrir Grafana mientras ejecutas:
./run_single_test.sh 75 120

# URL: http://10.43.100.87:3010
```

En Grafana, buscar:
- **CPU Usage** → ¿Cerca del 100%?
- **Memory Usage** → ¿Swapping?
- **Response Time P99** → ¿Picos?
- **Error Rate** → ¿Aumentando?

### Paso 4: Comparar con Más Recursos

```bash
# Escalar a 2 réplicas
ssh estudiante@10.43.100.87
microk8s kubectl scale deployment api -n apps --replicas=2

# Repetir prueba problemática
./run_single_test.sh 75 120

# Comparar: ¿Mejoró?
```

---

## 7. Captura para Presentación

**Objetivo:** Obtener datos y gráficas para la presentación del proyecto.

### Paso 1: Análisis Completo

```bash
# Ejecutar análisis completo
./load_test_analysis.sh

# Resultado:
# load_test_results_YYYYMMDD_HHMMSS/LOAD_TEST_REPORT.md
```

### Paso 2: Capturar Dashboards

```bash
# Obtener info de Grafana
./capture_grafana.sh

# Abrir Grafana en navegador
# http://10.43.100.87:3010

# Hacer screenshots de:
# 1. Dashboard de API Performance
# 2. Dashboard de Kubernetes Resources
# 3. Dashboard de Prometheus Metrics
```

### Paso 3: Ejecutar Prueba con Capturas

```bash
# Terminal 1: Ejecutar prueba
./run_single_test.sh 100 120

# Terminal 2: Abrir Locust
# http://10.43.100.87:8004
# Capturar screenshot de estadísticas

# Terminal 3: Abrir Grafana
# http://10.43.100.87:3010
# Capturar gráficas en tiempo real
```

### Paso 4: Organizar para Presentación

```bash
# Crear carpeta de presentación
mkdir presentation_materials

# Copiar reporte
cp load_test_results_*/LOAD_TEST_REPORT.md presentation_materials/

# Copiar screenshots (que hayas capturado manualmente)
mv ~/Screenshots/grafana_*.png presentation_materials/

# Copiar métricas clave
cp load_test_results_*/metrics/*_stats.json presentation_materials/
```

### Elementos para el Video

1. **Introducción (1 min)**
   - Mostrar arquitectura
   - Explicar configuración

2. **Demostración en Vivo (3 min)**
   - Ejecutar `./run_single_test.sh 50 60`
   - Mostrar Locust en tiempo real
   - Mostrar Grafana en tiempo real

3. **Resultados del Análisis (3 min)**
   - Abrir LOAD_TEST_REPORT.md
   - Mostrar tabla comparativa
   - Explicar comparación 1 vs 2 réplicas

4. **Métricas de Kubernetes (1 min)**
   - Mostrar métricas de pods
   - Explicar uso de CPU/memoria

5. **Conclusiones (2 min)**
   - Capacidad determinada
   - Recomendaciones de escalado
   - Observabilidad implementada

---

## 🎯 Checklist de Uso

### Para Entrega del Proyecto

- [ ] Ejecutar análisis completo (`./load_test_analysis.sh`)
- [ ] Guardar reporte generado
- [ ] Capturar screenshots de Grafana
- [ ] Documentar configuración usada
- [ ] Crear carpeta con todos los materiales

### Para Video de Sustentación

- [ ] Grabar ejecución de prueba en vivo
- [ ] Mostrar Locust en tiempo real
- [ ] Mostrar Grafana durante la prueba
- [ ] Explicar reporte generado
- [ ] Mostrar métricas de Kubernetes

### Para Análisis Personal

- [ ] Verificar que todos los servicios funcionan
- [ ] Ejecutar prueba de baseline (10 usuarios)
- [ ] Ejecutar análisis completo
- [ ] Revisar reporte generado
- [ ] Identificar puntos de mejora

---

## 💡 Tips Finales

1. **Siempre empieza con una prueba pequeña** (10 usuarios) para verificar que todo funciona

2. **Monitorea en tiempo real** - Abre Grafana y Locust en navegador durante las pruebas

3. **No ejecutes múltiples pruebas simultáneamente** - Espera que una termine antes de iniciar otra

4. **Guarda los resultados** - Los reportes generados son valiosos para comparaciones

5. **Lee el reporte completo** - Tiene análisis y recomendaciones útiles

6. **Si algo falla, revisa los logs** - `cat load_test_results_*/test.log`

---

**¿Necesitas ayuda?** Revisa `LOAD_TEST_README.md` para documentación completa.

---

*Buena suerte con tu proyecto! 🚀*
