#!/usr/bin/env bash
#
# Script de Análisis Automatizado de Pruebas de Carga
# Proyecto 3 - MLOps
#
# Ejecuta pruebas progresivas con Locust, captura métricas de Kubernetes,
# escala el deployment, compara resultados y genera reporte.
#

set -euo pipefail

# ============================================================================
# CONFIGURACIÓN
# ============================================================================

# VM Configuration
VM_HOST="10.43.100.87"
VM_USER="estudiante"
VM_PASSWORD="Fl4m3nc0*15*"

# URLs
LOCUST_URL="http://${VM_HOST}:8004"
API_URL="http://${VM_HOST}:8001"
GRAFANA_URL="http://${VM_HOST}:3010"
PROMETHEUS_URL="http://${VM_HOST}:3011"

# Grafana credentials
GRAFANA_USER="admin"
GRAFANA_PASSWORD="admin123"

# Test configuration
TEST_USERS=(10 25 50 100 200)
SPAWN_RATE=5
TEST_DURATION=60  # segundos

# Kubernetes
K8S_NAMESPACE="apps"
K8S_DEPLOYMENT="api"

# Directories
RESULTS_DIR="./load_test_results_$(date +%Y%m%d_%H%M%S)"
LOGS_DIR="${RESULTS_DIR}/logs"
METRICS_DIR="${RESULTS_DIR}/metrics"
SCREENSHOTS_DIR="${RESULTS_DIR}/screenshots"

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
DIM='\033[2m'
NC='\033[0m'

# ============================================================================
# FUNCIONES DE UTILIDAD
# ============================================================================

log() {
    local level="$1"
    shift
    local message="$*"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    
    # Crear directorio si no existe
    if [ -n "${RESULTS_DIR:-}" ]; then
        mkdir -p "${RESULTS_DIR}" 2>/dev/null || true
        echo "[$timestamp] [$level] $message" | tee -a "${RESULTS_DIR}/test.log" 2>/dev/null || echo "[$timestamp] [$level] $message"
    else
        echo "[$timestamp] [$level] $message"
    fi
}

info() {
    if [ -n "${RESULTS_DIR:-}" ] && [ -d "${RESULTS_DIR}" ]; then
        echo -e "${BLUE}ℹ${NC} $*" | tee -a "${RESULTS_DIR}/test.log"
    else
        echo -e "${BLUE}ℹ${NC} $*"
    fi
}

success() {
    if [ -n "${RESULTS_DIR:-}" ] && [ -d "${RESULTS_DIR}" ]; then
        echo -e "${GREEN}✓${NC} $*" | tee -a "${RESULTS_DIR}/test.log"
    else
        echo -e "${GREEN}✓${NC} $*"
    fi
}

warning() {
    if [ -n "${RESULTS_DIR:-}" ] && [ -d "${RESULTS_DIR}" ]; then
        echo -e "${YELLOW}⚠${NC} $*" | tee -a "${RESULTS_DIR}/test.log"
    else
        echo -e "${YELLOW}⚠${NC} $*"
    fi
}

error() {
    if [ -n "${RESULTS_DIR:-}" ] && [ -d "${RESULTS_DIR}" ]; then
        echo -e "${RED}✗${NC} $*" | tee -a "${RESULTS_DIR}/test.log"
    else
        echo -e "${RED}✗${NC} $*"
    fi
    exit 1
}

step() {
    local msg="\n${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    local content="${CYAN}▶${NC} ${BLUE}$*${NC}"
    
    if [ -n "${RESULTS_DIR:-}" ] && [ -d "${RESULTS_DIR}" ]; then
        echo -e "$msg" | tee -a "${RESULTS_DIR}/test.log"
        echo -e "$content" | tee -a "${RESULTS_DIR}/test.log"
        echo -e "$msg\n" | tee -a "${RESULTS_DIR}/test.log"
    else
        echo -e "$msg"
        echo -e "$content"
        echo -e "$msg\n"
    fi
}

ssh_exec() {
    local cmd="$1"
    sshpass -p "$VM_PASSWORD" ssh -o StrictHostKeyChecking=no \
        -o UserKnownHostsFile=/dev/null \
        -o LogLevel=ERROR \
        "${VM_USER}@${VM_HOST}" "$cmd"
}

wait_with_spinner() {
    local duration=$1
    local message="${2:-Esperando}"
    
    for ((i=1; i<=duration; i++)); do
        echo -ne "\r${DIM}${message}... ${i}/${duration}s${NC}"
        sleep 1
    done
    echo -ne "\r${NC}"
    echo ""
}

# ============================================================================
# FUNCIONES DE PRUEBAS
# ============================================================================

check_prerequisites() {
    step "Verificando prerrequisitos"
    
    # Check sshpass
    if ! command -v sshpass &> /dev/null; then
        error "sshpass no está instalado. Instálalo con: brew install hudochenkov/sshpass/sshpass"
    fi
    success "sshpass instalado"
    
    # Check curl
    if ! command -v curl &> /dev/null; then
        error "curl no está instalado"
    fi
    success "curl instalado"
    
    # Check jq
    if ! command -v jq &> /dev/null; then
        warning "jq no está instalado. Algunas funciones estarán limitadas."
        warning "Instala con: brew install jq"
    else
        success "jq instalado"
    fi
    
    # Check VM connectivity
    info "Verificando conexión SSH a ${VM_HOST}..."
    if ssh_exec "echo 'OK'" >/dev/null 2>&1; then
        success "Conexión SSH establecida"
    else
        error "No se pudo conectar a ${VM_HOST}"
    fi
    
    # Check services
    info "Verificando servicios..."
    
    local api_status=$(curl -s -o /dev/null -w "%{http_code}" "${API_URL}/health" || echo "000")
    if [ "$api_status" = "200" ]; then
        success "API disponible"
    else
        error "API no disponible (HTTP ${api_status})"
    fi
    
    local locust_status=$(curl -s -o /dev/null -w "%{http_code}" "${LOCUST_URL}" || echo "000")
    if [ "$locust_status" = "200" ]; then
        success "Locust disponible"
    else
        error "Locust no disponible (HTTP ${locust_status})"
    fi
}

setup_directories() {
    step "Configurando directorios"
    
    mkdir -p "$RESULTS_DIR"
    mkdir -p "$LOGS_DIR"
    mkdir -p "$METRICS_DIR"
    mkdir -p "$SCREENSHOTS_DIR"
    
    success "Directorios creados en: ${RESULTS_DIR}"
}

get_k8s_metrics() {
    local test_name="$1"
    local output_file="${METRICS_DIR}/${test_name}_k8s_metrics.txt"
    
    info "Capturando métricas de Kubernetes..."
    
    {
        echo "=== KUBERNETES METRICS ==="
        echo "Test: ${test_name}"
        echo "Timestamp: $(date)"
        echo ""
        
        echo "=== PODS ==="
        ssh_exec "microk8s kubectl get pods -n ${K8S_NAMESPACE}"
        echo ""
        
        echo "=== POD RESOURCES ==="
        ssh_exec "microk8s kubectl top pods -n ${K8S_NAMESPACE}"
        echo ""
        
        echo "=== DEPLOYMENT STATUS ==="
        ssh_exec "microk8s kubectl get deployment ${K8S_DEPLOYMENT} -n ${K8S_NAMESPACE}"
        echo ""
        
        echo "=== REPLICA SETS ==="
        ssh_exec "microk8s kubectl get rs -n ${K8S_NAMESPACE}"
        echo ""
        
        echo "=== SERVICES ==="
        ssh_exec "microk8s kubectl get svc -n ${K8S_NAMESPACE}"
        echo ""
        
        echo "=== EVENTS (últimos 10) ==="
        ssh_exec "microk8s kubectl get events -n ${K8S_NAMESPACE} --sort-by='.lastTimestamp' | tail -10"
        echo ""
        
    } > "$output_file"
    
    success "Métricas K8s guardadas en: ${output_file}"
}

get_prometheus_metrics() {
    local test_name="$1"
    local output_file="${METRICS_DIR}/${test_name}_prometheus_metrics.json"
    
    info "Capturando métricas de Prometheus..."
    
    # Query para obtener métricas de la API
    local queries=(
        "rate(predictions_total[1m])"
        "rate(prediction_errors_total[1m])"
        "histogram_quantile(0.95, rate(prediction_duration_seconds_bucket[1m]))"
        "histogram_quantile(0.99, rate(prediction_duration_seconds_bucket[1m]))"
    )
    
    {
        echo "{"
        echo "  \"test_name\": \"${test_name}\","
        echo "  \"timestamp\": \"$(date -Iseconds)\","
        echo "  \"metrics\": ["
        
        local first=true
        for query in "${queries[@]}"; do
            if [ "$first" = false ]; then
                echo ","
            fi
            first=false
            
            echo "    {"
            echo "      \"query\": \"${query}\","
            
            # Ejecutar query en Prometheus
            local result=$(curl -s "${PROMETHEUS_URL}/api/v1/query" \
                --data-urlencode "query=${query}" 2>/dev/null || echo '{}')
            
            echo "      \"result\": ${result}"
            echo -n "    }"
        done
        
        echo ""
        echo "  ]"
        echo "}"
    } > "$output_file"
    
    success "Métricas Prometheus guardadas en: ${output_file}"
}

run_locust_test() {
    local num_users=$1
    local test_name="test_${num_users}_users"
    local csv_prefix="${RESULTS_DIR}/${test_name}"
    
    info "Iniciando prueba con ${num_users} usuarios..."
    
    # Obtener métricas previas
    get_k8s_metrics "${test_name}_before"
    
    # Ejecutar prueba con Locust
    info "Ejecutando Locust (${TEST_DURATION}s)..."
    
    # Usar la API de Locust para iniciar el test
    # 1. Iniciar el swarm
    local start_payload=$(cat <<EOF
{
    "user_count": ${num_users},
    "spawn_rate": ${SPAWN_RATE},
    "host": "${API_URL}"
}
EOF
)
    
    curl -s -X POST "${LOCUST_URL}/swarm" \
        -H "Content-Type: application/json" \
        -d "$start_payload" > /dev/null
    
    success "Prueba iniciada: ${num_users} usuarios, spawn rate: ${SPAWN_RATE}"
    
    # Esperar duración del test + tiempo de spawn
    local total_wait=$((TEST_DURATION + (num_users / SPAWN_RATE) + 5))
    wait_with_spinner "$total_wait" "Ejecutando prueba"
    
    # Detener el test y obtener estadísticas
    info "Obteniendo estadísticas..."
    
    # Obtener stats
    curl -s "${LOCUST_URL}/stats/requests" > "${METRICS_DIR}/${test_name}_stats.json"
    
    # Detener el swarm
    curl -s -X GET "${LOCUST_URL}/stop" > /dev/null
    
    # Esperar un poco para que Locust procese todo
    sleep 3
    
    # Obtener métricas posteriores
    get_k8s_metrics "${test_name}_after"
    get_prometheus_metrics "${test_name}"
    
    success "Prueba completada: ${num_users} usuarios"
}

parse_locust_results() {
    local test_name="$1"
    local stats_file="${METRICS_DIR}/${test_name}_stats.json"
    
    if [ ! -f "$stats_file" ]; then
        warning "No se encontraron estadísticas para ${test_name}"
        return 1
    fi
    
    # Extraer métricas principales usando jq si está disponible
    if command -v jq &> /dev/null; then
        local total_requests=$(jq -r '.stats[0].num_requests // 0' "$stats_file")
        local total_failures=$(jq -r '.stats[0].num_failures // 0' "$stats_file")
        local avg_response_time=$(jq -r '.stats[0].avg_response_time // 0' "$stats_file")
        local min_response_time=$(jq -r '.stats[0].min_response_time // 0' "$stats_file")
        local max_response_time=$(jq -r '.stats[0].max_response_time // 0' "$stats_file")
        local median_response_time=$(jq -r '.stats[0].median_response_time // 0' "$stats_file")
        local requests_per_sec=$(jq -r '.stats[0].current_rps // 0' "$stats_file")
        
        echo "total_requests=${total_requests}"
        echo "total_failures=${total_failures}"
        echo "avg_response_time=${avg_response_time}"
        echo "min_response_time=${min_response_time}"
        echo "max_response_time=${max_response_time}"
        echo "median_response_time=${median_response_time}"
        echo "requests_per_sec=${requests_per_sec}"
    else
        warning "jq no disponible, saltando análisis detallado"
        echo "total_requests=N/A"
        echo "total_failures=N/A"
        echo "avg_response_time=N/A"
    fi
}

scale_deployment() {
    local replicas=$1
    
    step "Escalando deployment a ${replicas} réplicas"
    
    info "Escalando ${K8S_DEPLOYMENT} en namespace ${K8S_NAMESPACE}..."
    ssh_exec "microk8s kubectl scale deployment ${K8S_DEPLOYMENT} -n ${K8S_NAMESPACE} --replicas=${replicas}"
    
    info "Esperando que las réplicas estén listas..."
    ssh_exec "microk8s kubectl rollout status deployment/${K8S_DEPLOYMENT} -n ${K8S_NAMESPACE}"
    
    success "Deployment escalado a ${replicas} réplicas"
    
    # Mostrar estado
    ssh_exec "microk8s kubectl get pods -n ${K8S_NAMESPACE} -l app=${K8S_DEPLOYMENT}"
    
    # Esperar un poco más para estabilidad
    info "Esperando estabilización..."
    sleep 10
}

get_current_replicas() {
    ssh_exec "microk8s kubectl get deployment ${K8S_DEPLOYMENT} -n ${K8S_NAMESPACE} -o jsonpath='{.spec.replicas}'"
}

# ============================================================================
# GENERACIÓN DE REPORTE
# ============================================================================

generate_report() {
    local report_file="${RESULTS_DIR}/LOAD_TEST_REPORT.md"
    
    step "Generando reporte"
    
    info "Creando reporte en: ${report_file}"
    
    cat > "$report_file" <<'EOF'
# 📊 Reporte de Pruebas de Carga - Proyecto 3 MLOps

## 📋 Información General

EOF

    cat >> "$report_file" <<EOF
- **Fecha:** $(date '+%Y-%m-%d %H:%M:%S')
- **VM:** ${VM_HOST}
- **API:** ${API_URL}
- **Locust:** ${LOCUST_URL}
- **Duración por prueba:** ${TEST_DURATION}s
- **Spawn Rate:** ${SPAWN_RATE} usuarios/segundo

---

## 🧪 Pruebas Realizadas

### Fase 1: Pruebas Progresivas (1 Réplica)

EOF

    # Generar tabla de resultados - Fase 1
    cat >> "$report_file" <<'EOF'
| Usuarios | Requests | Failures | Avg (ms) | Min (ms) | Max (ms) | Median (ms) | RPS | Error % |
|----------|----------|----------|----------|----------|----------|-------------|-----|---------|
EOF

    for users in "${TEST_USERS[@]}"; do
        local test_name="test_${users}_users"
        local stats_file="${METRICS_DIR}/${test_name}_stats.json"
        
        if [ -f "$stats_file" ] && command -v jq &> /dev/null; then
            local total_req=$(jq -r '.stats[0].num_requests // 0' "$stats_file")
            local failures=$(jq -r '.stats[0].num_failures // 0' "$stats_file")
            local avg_time=$(jq -r '.stats[0].avg_response_time // 0' "$stats_file")
            local min_time=$(jq -r '.stats[0].min_response_time // 0' "$stats_file")
            local max_time=$(jq -r '.stats[0].max_response_time // 0' "$stats_file")
            local med_time=$(jq -r '.stats[0].median_response_time // 0' "$stats_file")
            local rps=$(jq -r '.stats[0].current_rps // 0' "$stats_file")
            
            local error_pct=0
            if [ "$total_req" -gt 0 ]; then
                error_pct=$(echo "scale=2; ($failures / $total_req) * 100" | bc)
            fi
            
            echo "| ${users} | ${total_req} | ${failures} | ${avg_time} | ${min_time} | ${max_time} | ${med_time} | ${rps} | ${error_pct}% |" >> "$report_file"
        else
            echo "| ${users} | N/A | N/A | N/A | N/A | N/A | N/A | N/A | N/A |" >> "$report_file"
        fi
    done

    cat >> "$report_file" <<'EOF'

### Fase 2: Prueba con 2 Réplicas

EOF

    # Tabla para prueba con 2 réplicas
    cat >> "$report_file" <<'EOF'
| Réplicas | Usuarios | Requests | Failures | Avg (ms) | Min (ms) | Max (ms) | Median (ms) | RPS | Error % |
|----------|----------|----------|----------|----------|----------|-------------|-----|---------|
EOF

    local test_100_1r="test_100_users"
    local test_100_2r="test_100_users_2replicas"
    
    for test_name in "$test_100_1r" "$test_100_2r"; do
        local replicas=$(echo "$test_name" | grep -q "2replicas" && echo "2" || echo "1")
        local stats_file="${METRICS_DIR}/${test_name}_stats.json"
        
        if [ -f "$stats_file" ] && command -v jq &> /dev/null; then
            local total_req=$(jq -r '.stats[0].num_requests // 0' "$stats_file")
            local failures=$(jq -r '.stats[0].num_failures // 0' "$stats_file")
            local avg_time=$(jq -r '.stats[0].avg_response_time // 0' "$stats_file")
            local min_time=$(jq -r '.stats[0].min_response_time // 0' "$stats_file")
            local max_time=$(jq -r '.stats[0].max_response_time // 0' "$stats_file")
            local med_time=$(jq -r '.stats[0].median_response_time // 0' "$stats_file")
            local rps=$(jq -r '.stats[0].current_rps // 0' "$stats_file")
            
            local error_pct=0
            if [ "$total_req" -gt 0 ]; then
                error_pct=$(echo "scale=2; ($failures / $total_req) * 100" | bc)
            fi
            
            echo "| ${replicas} | 100 | ${total_req} | ${failures} | ${avg_time} | ${min_time} | ${max_time} | ${med_time} | ${rps} | ${error_pct}% |" >> "$report_file"
        fi
    done

    cat >> "$report_file" <<'EOF'

---

## 📈 Análisis de Resultados

### Observaciones Generales

EOF

    # Análisis automático si jq está disponible
    if command -v jq &> /dev/null; then
        cat >> "$report_file" <<EOF
1. **Rendimiento con 1 réplica:**
   - El sistema manejó satisfactoriamente hasta X usuarios concurrentes
   - Latencia promedio se mantiene bajo XXXms hasta YY usuarios
   - A partir de ZZZ usuarios se observa degradación

2. **Impacto del escalado horizontal (2 réplicas):**
   - Mejora en throughput: +X%
   - Reducción en latencia: -Y%
   - Reducción en tasa de error: -Z%

3. **Capacidad máxima determinada:**
   - Con 1 réplica: XX usuarios concurrentes
   - Con 2 réplicas: YY usuarios concurrentes

EOF
    else
        cat >> "$report_file" <<EOF
> ⚠️ Análisis detallado no disponible (requiere jq). 
> Revisa los archivos JSON en el directorio \`metrics/\` para análisis manual.

EOF
    fi

    cat >> "$report_file" <<'EOF'

### Métricas de Kubernetes

Las métricas completas de Kubernetes (uso de CPU, memoria, pods) se encuentran en:
- Directorio: `metrics/`
- Archivos: `*_k8s_metrics.txt`

### Métricas de Prometheus

Las métricas de Prometheus (rates, percentiles) se encuentran en:
- Directorio: `metrics/`
- Archivos: `*_prometheus_metrics.json`

---

## 🎯 Conclusiones

### Recomendaciones

1. **Configuración óptima:**
   - Para carga normal (< X usuarios): 1 réplica suficiente
   - Para carga alta (> Y usuarios): Mínimo 2 réplicas

2. **Escalado automático:**
   - Configurar HPA (Horizontal Pod Autoscaler)
   - Threshold sugerido: CPU > 70% o Latencia P95 > XXXms

3. **Monitoreo:**
   - Alertas en Prometheus para latencia P99 > XXXms
   - Alertas para error rate > X%

---

## 📂 Archivos Generados

EOF

    cat >> "$report_file" <<EOF
- \`logs/\`: Logs detallados de las pruebas
- \`metrics/\`: Métricas de K8s y Prometheus
- \`screenshots/\`: Capturas de Grafana (si disponibles)

**Total de archivos:** $(find "$RESULTS_DIR" -type f | wc -l)

---

*Reporte generado automáticamente el $(date '+%Y-%m-%d %H:%M:%S')*
EOF

    success "Reporte generado: ${report_file}"
}

# ============================================================================
# FUNCIÓN PRINCIPAL
# ============================================================================

main() {
    # Banner
    echo -e "${CYAN}"
    echo "╔════════════════════════════════════════════════════════════════╗"
    echo "║     ANÁLISIS AUTOMATIZADO DE PRUEBAS DE CARGA                 ║"
    echo "║     Proyecto 3 - MLOps                                         ║"
    echo "╚════════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    # Setup
    check_prerequisites
    setup_directories
    
    # Guardar réplicas originales
    local original_replicas=$(get_current_replicas)
    info "Réplicas originales: ${original_replicas}"
    
    # FASE 1: Pruebas progresivas con 1 réplica
    step "FASE 1: Pruebas progresivas (1 réplica)"
    
    # Asegurar que tengamos 1 réplica
    scale_deployment 1
    
    for users in "${TEST_USERS[@]}"; do
        run_locust_test "$users"
        
        # Pequeña pausa entre pruebas
        info "Pausa entre pruebas..."
        sleep 5
    done
    
    success "Fase 1 completada"
    
    # FASE 2: Escalar a 2 réplicas y repetir prueba de 100 usuarios
    step "FASE 2: Prueba con 2 réplicas"
    
    scale_deployment 2
    
    # Ejecutar prueba con 100 usuarios
    info "Ejecutando prueba con 100 usuarios y 2 réplicas..."
    
    local test_name="test_100_users_2replicas"
    local csv_prefix="${RESULTS_DIR}/${test_name}"
    
    get_k8s_metrics "${test_name}_before"
    
    local start_payload=$(cat <<EOF
{
    "user_count": 100,
    "spawn_rate": ${SPAWN_RATE},
    "host": "${API_URL}"
}
EOF
)
    
    curl -s -X POST "${LOCUST_URL}/swarm" \
        -H "Content-Type: application/json" \
        -d "$start_payload" > /dev/null
    
    success "Prueba iniciada: 100 usuarios, 2 réplicas"
    
    local total_wait=$((TEST_DURATION + (100 / SPAWN_RATE) + 5))
    wait_with_spinner "$total_wait" "Ejecutando prueba"
    
    curl -s "${LOCUST_URL}/stats/requests" > "${METRICS_DIR}/${test_name}_stats.json"
    curl -s -X GET "${LOCUST_URL}/stop" > /dev/null
    sleep 3
    
    get_k8s_metrics "${test_name}_after"
    get_prometheus_metrics "${test_name}"
    
    success "Fase 2 completada"
    
    # Restaurar configuración original
    step "Restaurando configuración original"
    scale_deployment "$original_replicas"
    
    # Generar reporte
    generate_report
    
    # Resumen final
    echo -e "\n${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}                    ANÁLISIS COMPLETADO${NC}"
    echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}\n"
    
    success "Todos los resultados guardados en: ${RESULTS_DIR}"
    success "Reporte principal: ${RESULTS_DIR}/LOAD_TEST_REPORT.md"
    
    echo -e "\n${CYAN}📊 Archivos generados:${NC}"
    echo -e "  - Logs: ${LOGS_DIR}"
    echo -e "  - Métricas: ${METRICS_DIR}"
    echo -e "  - Reporte: ${RESULTS_DIR}/LOAD_TEST_REPORT.md"
    
    echo -e "\n${CYAN}🔗 Enlaces útiles:${NC}"
    echo -e "  - Grafana: ${GRAFANA_URL}"
    echo -e "  - Prometheus: ${PROMETHEUS_URL}"
    echo -e "  - Locust: ${LOCUST_URL}"
    
    echo -e "\n${GREEN}✓ Análisis completado exitosamente${NC}\n"
}

# Ejecutar
main "$@"
